<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>{{ $resetData['subject'] }}</title>
</head>
<body>
    <h1>Halo, {{ $resetData['name'] }}!</h1>
    <p>Token: {{ $resetData['token']}}</p>
    <p>Link: {{ $resetData['resetLink']}}</p>
</body>
</html>