<?php

namespace App\Http\Controllers\Todo;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\TaskList;
use App\Enums\Prioritas;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class TodoController extends Controller {
  
  public function index(Request $request) {
    $id_user = auth()->user()->id_user;
    $query = Task::where('id_user', $id_user)->with('subtasks');
    
    if ($request->has('search')) {
      $query->where('judul_task', 'like', '%'.$request->search.'%');
    }
    
    if ($request->has('priority') && $request->priority !== "all" && $request->priority !== "") {
      $query->where('priority', $request->priority);
    }
    
    $data = $query->orderBy('judul_task', 'asc')->get();
    
    // Jika AJAX, kembalikan partial view
    if ($request->ajax()) {
        return view('partials.dashboard_tasks', compact('data'))->render();
    }
    
    $belumSelesai = Task::where('status_task', 'belum_selesai')->where('id_user', $id_user)->count();
    $selesai = Task::where('status_task', 'selesai')->where('id_user', $id_user)->count();
    //$terlambat = Task::where('status_task', 'terlambat')->where('id_user', $id_user)->where('deadline', '<', Carbon::now())->count();
    $terlambat = Task::where('status_task', 'terlambat')->where('id_user', $id_user)->count();
    
    return view("dashboard", compact('data', 'belumSelesai', 'selesai', 'terlambat'));
}


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
     
     
    public function store(Request $request) {
      
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
    
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
    
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request) {
      
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id_task) {
    }
    
    
    public function updateStatus(Request $request, string $id_task) {
      
      //dd($request->all());
    // Temukan task berdasarkan id
    $task = Task::findOrFail($id_task);
    
    // Perbarui status task dengan nilai dari form
    $task->status_task = $request->input('status_task');
    $task->save();
    
    // Redirect kembali ke dashboard atau kirim respons JSON jika diperlukan
    /*return redirect()->back()->with('sukses', 'Status task telah diperbarui.');*/
      return response()->json([
        'success' => true,
        'new_status' => $task->status_task,
      ]);
    }
    /*public function updateStatus(Request $request, string $id_task) {
    // Validasi input jika diperlukan
    $request->validate([
        'status_task' => 'required|string'
    ]);

    // Temukan task berdasarkan id_task, atau otomatis error jika tidak ditemukan
    $task = Task::findOrFail($id_task);
    
    // Update status task dengan nilai yang dikirim
    $task->status_task = $request->input('status_task');
    $task->save();
    
    return response()->json([
        'success' => true,
        'new_status' => $task->status_task,
        'message' => 'Status task berhasil diperbarui'
    ]);
}*/

    
    
    public function updateStatussub(Request $request, string $id_subtask) {
      // Validasi data yang dikirim (sesuaikan dengan nilai enum Anda)

      $subtask = TaskList::findOrFail($id_subtask);
      $subtask->status_subtask = $request->status_subtask;
      $subtask->save();
      
      return response()->json([
        'success' => true,
        'subtask' => $subtask
      ]);
    }
    /*public function updateStatussub(Request $request, string $id_subtask) {
      // Validasi data yang dikirim (sesuaikan dengan nilai enum Anda)

      $subtask = TaskList::findOrFail($id_subtask);
      $subtask->status_subtask = $request->status_subtask;
      $subtask->save();
      
      return response()->json([
        'success' => true,
        'subtask' => $subtask
      ]);
    }*/
    

    
  /*public function updateSubtask(Request $request) {
    // Validasi input tanpa field status_subtask
    $validated = $request->validate([
        'id_subtask'         => 'required|exists:subtasks,id_subtask',
        'judul_subtask'      => 'required|string|max:255',
        'keterangan_subtask' => 'nullable|string',
    ]);

    // Ambil subtask yang akan diupdate
    $subtask = TaskList::findOrFail($validated['id_subtask']);

    // Update data subtask (tidak menggunakan status_subtask)
    $subtask->judul_subtask      = $validated['judul_subtask'];
    $subtask->keterangan_subtask = $validated['keterangan_subtask'] ?? null;

    $subtask->save();

    // Kembalikan respons JSON agar AJAX dapat menangani update tanpa reload
    return response()->json([
        'success' => true,
        'subtask' => $subtask
    ]);
}*/

public function updateSubtask(Request $request) {
    // Validasi input, termasuk id_subtask dan id_task
    $validated = $request->validate([
        'id_task'            => 'required|exists:task,id_task',
        'id_subtask'         => 'required|exists:task_list,id_subtask',
        'judul_subtask'      => 'required|string|max:255',
        'keterangan_subtask' => 'nullable|string',
    ]);

    // Ambil subtask berdasarkan id_subtask
    $subtask = TaskList::findOrFail($validated['id_subtask']);

    // Pastikan subtask terkait dengan task yang diberikan
    if ($subtask->id_task != $validated['id_task']) {
        return response()->json([
            'success' => false,
            'message' => 'Subtask tidak terkait dengan task yang diberikan.'
        ], 422);
    }

    // Update data subtask (tanpa mengubah field status_subtask)
    $subtask->judul_subtask = $validated['judul_subtask'];
    $subtask->keterangan_subtask = $validated['keterangan_subtask'] ?? null;
    $subtask->save();

    // Kembalikan respons JSON agar AJAX dapat menangani update tanpa reload halaman
    return response()->json([
        'success' => true,
        'subtask' => $subtask
    ]);
}


}