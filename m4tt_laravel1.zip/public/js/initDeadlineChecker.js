function initDeadlineChecker() {
  let now = new Date();
  let cards = document.querySelectorAll('.todo-card');
  cards.forEach(function(card) {
    let deadlineStr = card.getAttribute('data-deadline');
    let taskId = card.getAttribute('data-task-id');
    if (deadlineStr && taskId) {
      // Jika ada spasi, ganti dengan "T" agar kompatibel dengan Date
      if (deadlineStr.indexOf(' ') > -1) {
        deadlineStr = deadlineStr.replace(' ', 'T');
      }
      let deadline = new Date(deadlineStr);
      let diffMs = deadline - now;
      let diffHours = diffMs / (1000 * 60 * 60);
      // Jika sisa waktu kurang dari 24 jam, kirim notifikasi
      if (diffHours > 0 && diffHours <= 24) {
        fetch(`/send-notification/${taskId}`)
          .then(response => response.text())
          .then(result => console.log("Notifikasi dikirim untuk task " + taskId + ": " + result))
          .catch(error => console.error("Error:", error));
        }
        // Jika deadline telah lewat, nonaktifkan tombol pada card
        if (now > deadline) {
          card.classList.add('disabled-task');
            
          let subtaskInfos = card.querySelectorAll('.subtask-info');
          subtaskInfos.forEach(function(subtaskInfo) {
          subtaskInfo.classList.add('disabled-task');
        });
        
        let updateButtons = card.querySelectorAll('.update-subtask');
        updateButtons.forEach(function(btn) {
          btn.classList.add('disabled-task');
          btn.disabled = true;
        });
        // Nonaktifkan tombol di dalam card (misal dengan id "dilet", "editz", "tambah-subtasks")
        let buttons = card.querySelectorAll("#editz, #tambah-subtasks");
        buttons.forEach(function(btn) {
              btn.disabled = true;
        });
      }
    }
  });
  /**
     * Modul: Deadline Checker
     * Memeriksa deadline setiap .todoo-card dan mengirim notifikasi jika deadline mendekati.
     * Jika deadline sudah lewat, nonaktifkan tombol pada card tersebut.
     */
}
document.addEventListener("DOMContentLoaded", function(){
  initDeadlineChecker();
  setInterval(initDeadlineChecker, 1 * 60 * 1000);
});