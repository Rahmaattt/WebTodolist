/*function initDeleteSubtask() {
  var deleteButtons = document.querySelectorAll('.delete-subtask');
  if (!deleteButtons.length) return;

  deleteButtons.forEach(function(button) {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      var idSubtask = button.getAttribute('data-id');

      Swal.fire({
        title: 'Ingin hapus subtask?',
        text: "Anda tidak akan bisa mengembalikannya",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: 'Ya, hapus subtask!',
        cancelButtonText: 'Tidak'
      }).then((result) => {
        if (result.isConfirmed) {
          fetch("{{ route('subtask.deleteSubtask') }}", {
            method: 'DELETE',
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
              "Accept": "application/json"
            },
            body: JSON.stringify({ id_subtask: idSubtask })
          })
          .then(response => response.json())
          .then(function(data) {
            if (data.success) {
              Swal.fire('Terhapus!', 'Subtask telah berhasil dihapus.', 'success');
              // Hapus elemen list subtask dari tampilan
              var listItem = button.closest('.listSubtask');
              if (listItem) {
                listItem.remove();
              }
            } else {
              Swal.fire('Gagal!', 'Subtask gagal dihapus.', 'error');
            }
          })
          .catch(function(error) {
            Swal.fire('Error!', 'Terjadi error: ' + error, 'error');
          });
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          Swal.fire({
            title: "Batal",
            text: "Subtask tidak jadi dihapus.",
            icon: "info",
            //timer: 1500,
            showConfirmButton: false
          });
        }
      });
    });
  });
}*/
/*function initDeleteSubtask() {
  const deleteButtons = document.querySelectorAll(".delete-subtask");
  if (!deleteButtons.length) return;

  deleteButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault();
      const idSubtask = button.getAttribute("data-id");

      Swal.fire({
        title: "Ingin hapus subtask?",
        text: "Anda tidak akan bisa mengembalikannya",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Ya, hapus subtask!",
        cancelButtonText: "Tidak",
      }).then((result) => {
        if (result.isConfirmed) {
          fetch(window.routes.deleteSubtask, {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
              Accept: "application/json",
            },
            body: JSON.stringify({ id_subtask: idSubtask }),
          })
            .then((response) => response.json())
            .then((data) => {
              if (data.success) {
                Swal.fire("Terhapus!", "Subtask telah berhasil dihapus.", "success");
                // Hapus elemen list subtask dari tampilan
                const listItem = button.closest(".listSubtask");
                if (listItem) {
                  listItem.remove();
                }
              } else {
                Swal.fire("Gagal!", "Subtask gagal dihapus.", "error");
              }
            })
            .catch((error) => {
              Swal.fire("Error!", "Terjadi error: " + error, "error");
            });
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          Swal.fire({
            title: "Batal",
            text: "Subtask tidak jadi dihapus.",
            icon: "info",
            showConfirmButton: false,
          });
        }
      });
    });
  });
}*/
function initDeleteSubtask() {
  document.addEventListener('click', function (e) {
    if (e.target.classList.contains('delete-subtask')) {
      e.preventDefault();
      const button = e.target;
      const idSubtask = button.getAttribute("data-id");

      Swal.fire({
        title: "Ingin hapus subtask?",
        text: "Anda tidak akan bisa mengembalikannya",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Ya, hapus subtask!",
        cancelButtonText: "Tidak",
      }).then((result) => {
        if (result.isConfirmed) {
          fetch(window.routes.deleteSubtask, {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
              Accept: "application/json",
            },
            body: JSON.stringify({ id_subtask: idSubtask }),
          })
            .then((response) => response.json())
            .then((data) => {
              if (data.success) {
                Swal.fire("Terhapus!", "Subtask telah berhasil dihapus.", "success");
                const listItem = button.closest(".listSubtask");
                if (listItem) {
                  listItem.remove();
                }
              } else {
                Swal.fire("Gagal!", "Subtask gagal dihapus.", "error");
              }
            })
            .catch((error) => {
              Swal.fire("Error!", "Terjadi error: " + error, "error");
            });
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          Swal.fire({
            title: "Batal",
            text: "Subtask tidak jadi dihapus.",
            icon: "info",
            showConfirmButton: false,
          });
        }
      });
    }
  });
}

document.addEventListener("DOMContentLoaded", function(){
  initDeleteSubtask();
});