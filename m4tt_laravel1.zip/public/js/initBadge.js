function initBadge() {
        var cards = document.querySelectorAll(".todo-card");
        cards.forEach(function(card) {
          var badge = card.querySelector(".badge");
          var cardPriority = card ? card.getAttribute("data-priority") : null;
          if (cardPriority === "tinggi") {
            badge.classList.remove("bg-priority-medium", "bg-priority-low");
            badge.classList.add("bg-priority-high");
          } else if (cardPriority === "sedang") {
            badge.classList.remove("bg-priority-high", "bg-priority-low");
            badge.classList.add("bg-priority-medium");
          } else {
            badge.classList.remove("bg-priority-high", "bg-priority-medium");
            badge.classList.add("bg-priority-low");
          }
        });
      }

document.addEventListener("DOMContentLoaded", function () {
  initBadge();
});