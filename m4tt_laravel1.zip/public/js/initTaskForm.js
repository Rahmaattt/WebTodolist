/*function initTaskForm() {
  var formTask = document.getElementById("tambahhtask");
  if (!formTask) return;

  formTask.addEventListener("submit", function(e) {
    e.preventDefault();

    var missingFields = [];
    var invalidFields = [];

    // Daftar field yang divalidasi sesuai dengan form tambah task
    var fields = [
      {
        id: "task",
        label: "Judul Task",
        regex: /^[a-zA-Z0-9 @]+$/,
        errorMsg: "Task hanya boleh berisi huruf, angka, spasi, dan @"
      },
      {
        id: "keterangan",
        label: "Keterangan Task",
        regex: /^[a-zA-Z0-9 @]+$/,
        errorMsg: "Keterangan hanya boleh berisi huruf, angka, spasi, dan @"
      },
      {
        id: "deadline",
        label: "Deadline",
        regex: /.+/,
        errorMsg: "Deadline harus diisi"
      },
      {
        id: "prioritas",
        label: "Prioritas",
        regex: /.+/,
        errorMsg: "Prioritas harus diisi"
      }
    ];

    // Validasi tiap field
    fields.forEach(function(field) {
      var input = formTask.querySelector("#" + field.id);
      if (input) {
        var value = input.value.trim();
        if (value === "") {
          missingFields.push(field.label);
        } else if (field.regex && !field.regex.test(value)) {
          invalidFields.push(field.errorMsg);
        }
      }
    });

    if (missingFields.length > 0) {
      Swal.fire({
        icon: "warning",
        title: "Field belum terisi!",
        html: "<strong>Field kosong:</strong><br>" + missingFields.join(", "),
        confirmButtonText: "Mengerti"
      });
      return;
    } else if (invalidFields.length > 0) {
      Swal.fire({
        icon: "warning",
        title: "Field tidak valid!",
        html: "<strong>Field tidak valid:</strong><br>" + invalidFields.join("<br>"),
        confirmButtonText: "Mengerti"
      });
      return;
    }

    var formData = new FormData(formTask);

    // Lakukan fetch untuk mengirim data ke endpoint taskStore
    fetch(window.routes.taskStore, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then(response => response.json())
      .then(function(data) {
        if (data.success) {
          Swal.fire({
            icon: "success",
            title: "Berhasil!",
            text: "Task berhasil ditambahkan.",
            confirmButtonText: "Mengerti"
          });

          // Buat HTML untuk task baru menggunakan template literal
          var newTaskHtml = `
          <div class="col-12 col-md-6 mb-3">
            <div class="card ${
              data.task.prioritas === 'tinggi'
                ? 'priority-tinggi'
                : data.task.prioritas === 'sedang'
                ? 'priority-sedang'
                : 'priority-rendah'
            } todo-card"
                 data-priority="${data.task.prioritas}"
                 data-deadline="${data.task.deadline}"
                 data-task-id="${data.task.id_task}"
                 data-created="${data.task.created_at}"
                 data-status-task="${data.task.status_task}">
              <div class="card-header bg-primary text-white">
                <div class="row w-100">
                  <div class="col-12">
                    <h3 class="task-title mb-0">
                      <span class="task-text">${data.task.judul_task}</span>
                    </h3>
                  </div>
                  <div class="col-6">
                    <small class="task-date text-light">Tanggal Pembuatan: ${data.task.created_at}</small>
                  </div>
                  <div class="col-6 text-end">
                    <span class="badge bg-priority-medium">Prioritas: ${data.task.prioritas}</span>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="subtask-info mb-3">
                  <h6 class="mb-2">Subtask:</h6>
                  <ul class="list-group list-group-flush overflow-auto" style="max-height: 200px;">
                    <!-- Subtask akan ditambahkan secara dinamis -->
                  </ul>
                </div>
                <hr>
                <div class="due-date">
                  <span class="d-block mb-2">
                    Waktu Tenggat: ${data.task.deadline}
                  </span>
                  <span class="d-block mb-2">
                    Prioritas: ${data.task.prioritas}
                  </span>
                  <span class="d-block mb-2">
                    Status Task: ${data.task.status_task}
                  </span>
                </div>
              </div>
              <div class="card-footer bg-light d-flex justify-content-between align-items-center">
                <div class="btn-group gap-2">
                  <button id="tambah-subtasks" type="button" class="btn btn-outline-primary btn-sm tambah-subtask">
                    Tambah Subtask
                  </button>
                  <form class="update-status-form" data-action="{{ route('dashboard.updateStatus', ['id_task' => $item->id_task]) }}" method="POST">
                  @csrf
                  <input type="hidden" name="status_task" data-id="{{ $item->id_task }}" value="{{ $item->status_task === 'selesai' ? 'belum_selesai' : 'selesai' }}">
                  <button id="selesaiii" type="button" class="btn btn-sm done-btn {{ $item->status_task === 'selesai' ? 'btn-warning' : 'btn-primary' }}" data-id="{{ $item->id }}">
                    {{ $item->status_task === 'selesai' ? 'Batalkan' : 'Selesai' }}
                  </button>
                </form>
                            <form class="formDilet" >
                @csrf
                <!--@method('delete')-->
                <button id="dilet" type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $item->id_task }}"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash2-fill" viewBox="0 0 16 16">
  <path d="M2.037 3.225A.7.7 0 0 1 2 3c0-1.105 2.686-2 6-2s6 .895 6 2a.7.7 0 0 1-.037.225l-1.684 10.104A2 2 0 0 1 10.305 15H5.694a2 2 0 0 1-1.973-1.671zm9.89-.69C10.966 2.214 9.578 2 8 2c-1.58 0-2.968.215-3.926.534-.477.16-.795.327-.975.466.18.14.498.307.975.466C5.032 3.786 6.42 4 8 4s2.967-.215 3.926-.534c.477-.16.795-.327.975-.466-.18-.14-.498-.307-.975-.466z"/>
</svg></button>
<!-- ✕ -->
              </form>
                </div>
                <button type="button" class="btn btn-primary btn-sm edit-btn" 
                        data-task="${data.task.judul_task}"
                        data-keterangan="${data.task.keterangan_task}"
                        data-deadline="${data.task.deadline}"
                        data-task-id="${data.task.id_task}"
                        data-status="{{ $item->status_task->value }}>
                  Edit Task
                </button>
              </div>
            </div>
          </div>
          `;

          // Sisipkan task baru ke dalam daftar task
          var todoList = document.getElementById("todo-list");
          if (todoList) {
            todoList.insertAdjacentHTML("beforeend", newTaskHtml);
          }

          formTask.reset();
          var modalTask = document.getElementById("tambahTaskModal");
          var modalInstance = bootstrap.Modal.getInstance(modalTask);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire({
            icon: "error",
            title: "Gagal!",
            text: "Terjadi kesalahan saat menambah task.",
            confirmButtonText: "Mengerti"
          });
        }
      })
      .catch(function (error) {
        Swal.fire({
          icon: "error",
          title: "Error!",
          text: "Terjadi kesalahan pada AJAX: " + error,
          confirmButtonText: "Mengerti"
        });
      });
  });
}*/

function formatTanggalIndo(datetimeStr) {
  const options = {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  };
  const date = new Date(datetimeStr);
  return date.toLocaleString("id-ID", options);
}

function initTaskForm() {
  const formTask = document.getElementById("tambahhtask");
  if (!formTask) return;

  formTask.addEventListener("submit", function (e) {
    e.preventDefault();

    const missingFields = [];
    const invalidFields = [];

    const fields = [
      {
        id: "task",
        label: "Judul Task",
        regex: /^[a-zA-Z0-9 @]+$/,
        errorMsg: "Task hanya boleh berisi huruf, angka, spasi, dan @"
      },
      {
        id: "keterangan",
        label: "Keterangan Task",
        regex: /^[a-zA-Z0-9 @]+$/,
        errorMsg: "Keterangan hanya boleh berisi huruf, angka, spasi, dan @"
      },
      {
        id: "deadline",
        label: "Deadline",
        regex: /.+/,
        errorMsg: "Deadline harus diisi"
      },
      {
        id: "prioritas",
        label: "Prioritas",
        regex: /.+/,
        errorMsg: "Prioritas harus diisi"
      }
    ];

    fields.forEach((field) => {
      const input = formTask.querySelector("#" + field.id);
      const value = input?.value.trim();
      if (!value) {
        missingFields.push(field.label);
      } else if (field.regex && !field.regex.test(value)) {
        invalidFields.push(field.errorMsg);
      }
    });

    if (missingFields.length > 0) {
      Swal.fire({
        icon: "warning",
        title: "Field belum terisi!",
        html: "<strong>Field kosong:</strong><br>" + missingFields.join(", "),
        confirmButtonText: "Mengerti"
      });
      return;
    } else if (invalidFields.length > 0) {
      Swal.fire({
        icon: "warning",
        title: "Field tidak valid!",
        html: "<strong>Field tidak valid:</strong><br>" + invalidFields.join("<br>"),
        confirmButtonText: "Mengerti"
      });
      return;
    }

    const formData = new FormData(formTask);

    fetch(window.routes.taskStore, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          const task = data.task;

          const newTaskHtml = `
          <div class="col-12 col-md-6 mb-3">
            <div class="card priority-${task.prioritas} todo-card"
                 data-priority="${task.prioritas}"
                 data-deadline="${task.deadline}"
                 data-task-id="${task.id_task}"
                 data-created="${task.created_at}"
                 data-status-task="${task.status_task}">
              <div class="card-header bg-primary text-white">
                <div class="row w-100">
                  <div class="col-12">
                    <h3 class="task-title mb-0"><span class="task-text">${task.judul_task}</span></h3>
                  </div>
                  <div class="col-6">
                    <small class="task-date text-light">Tanggal Pembuatan: ${formatTanggalIndo(task.created_at)}</small>
                  </div>
                  <div class="col-6 text-end">
                    <span class="badge bg-priority-medium">Prioritas: ${task.prioritas}</span>
                  </div>
                </div>
              </div>
              <div class="card-body bg-light">
                <div class="subtask-info mb-3">
                  <h6 class="mb-2">Subtask:</h6>
                  <ul class="list-group list-group-flush overflow-auto" style="max-height: 200px;"></ul>
                </div>
                <hr>
                <div class="due-date">
                  <span class="d-block mb-2">Waktu Tenggat: ${formatTanggalIndo(task.deadline)}</span>
                  <span class="d-block mb-2">Prioritas: ${task.prioritas}</span>
                  <span class="d-block mb-2">Status Task: ${task.status_task}</span>
                </div>
              </div>
              <div class="card-footer bg-light d-flex justify-content-between align-items-center">
                <div class="btn-group gap-2">
                  <button type="button" class="btn btn-outline-primary btn-sm tambah-subtask" data-id="${task.id_task}">Tambah Subtask</button>
                  <form class="update-status-form" action="/dashboard/updateStatus/${task.id_task}" method="POST">
                  <input type="hidden" name="status_task" value="…">
                  <button type="button" class="btn bg-primary btn-sm done-btn" data-id="…">Selesai</button>
                  </form>
                  <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="${task.id_task}"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash2-fill" viewBox="0 0 16 16">
  <path d="M2.037 3.225A.7.7 0 0 1 2 3c0-1.105 2.686-2 6-2s6 .895 6 2a.7.7 0 0 1-.037.225l-1.684 10.104A2 2 0 0 1 10.305 15H5.694a2 2 0 0 1-1.973-1.671zm9.89-.69C10.966 2.214 9.578 2 8 2c-1.58 0-2.968.215-3.926.534-.477.16-.795.327-.975.466.18.14.498.307.975.466C5.032 3.786 6.42 4 8 4s2.967-.215 3.926-.534c.477-.16.795-.327.975-.466-.18-.14-.498-.307-.975-.466z"/>
</svg></button>
                </div>
                <button type="button" class="btn btn-primary btn-sm edit-btn"
                        data-task="${task.judul_task}"
                        data-keterangan="${task.keterangan_task}"
                        data-deadline="${task.deadline}"
                        data-task-id="${task.id_task}"
                        data-status="${data.task.status_task}">
                  ✎
                </button>
              </div>
            </div>
          </div>`;

          const todoList = document.getElementById("todo-list");
          if (todoList) {
            todoList.insertAdjacentHTML("beforeend", newTaskHtml);
            if (typeof initBadge === "function") {
              initBadge();
            }
            if (typeof initDatetimeLocal === "function") {
              initDatetimeLocal();
            }
            if (typeof initTaskSort === "function") {
              initTaskSort();
            }
            if (typeof initTaskStatusUpdater === "function") {
              initTaskStatusUpdater();
            }
          }
          
          if (data.subtask) {
  const card = todoList.querySelector(`.todo-card[data-task-id="${task.id_task}"]`);
  const ul = card.querySelector(".subtask-info ul");
  const liHtml = /*`
    <li class="list-group-item listSubtask d-flex justify-content-between align-items-start">
      <div class="form-check">
        <input class="form-check-input subtask-checkbox" type="checkbox"
               data-id="${data.subtask.id_subtask}"
               ${data.subtask.status_subtask === 'selesai' ? 'checked' : ''}>
        <label class="form-check-label">
          ${data.subtask.judul_subtask}
        </label>
        <p class="subtask-desc mb-0">Keterangan: ${data.subtask.keterangan_subtask}</p>
      </div>
      <button type="button" class="btn btn-outline-primary btn-sm update-subtask">Edit Subtask</button>
                  <button type="button" class="btn btn-outline-danger btn-sm delete-subtask" data-id="${data.subtask.id_subtask}">Hapus Subtask</button>
    </li>`;*/
    `<li class="list-group-item listSubtask">
                  <label>
                    <input type="checkbox" class="subtask-checkbox" data-id="${data.subtask.id_subtask}" ${data.subtask.status_subtask === 'selesai' ? 'checked' : ''}>
                    ${data.subtask.judul_subtask}
                  </label>
                  <p class="subtask-desc mb-0">Keterangan: ${data.subtask.keterangan_subtask}</p>
                  <button type="button" class="btn btn-outline-primary btn-sm update-subtask">Edit Subtask</button>
                  <button type="button" class="btn btn-outline-danger btn-sm delete-subtask" data-id="${data.subtask.id_subtask}">Hapus Subtask</button>
                </li>`;
  ul.insertAdjacentHTML("beforeend", liHtml);
}

   

          formTask.reset();
          const modal = bootstrap.Modal.getInstance(document.getElementById("tambahTaskModal"));
          if (modal) modal.hide();

          Swal.fire({
            icon: "success",
            title: "Berhasil!",
            text: "Task berhasil ditambahkan.",
            confirmButtonText: "Oke"
          });
        } else {
          Swal.fire({
            icon: "error",
            title: "Gagal!",
            text: "Terjadi kesalahan saat menambah task.",
            confirmButtonText: "Mengerti"
          });
        }
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Error!",
          text: "Terjadi kesalahan: " + error,
          confirmButtonText: "Mengerti"
        });
      });
  });
}
/*function initTaskForm() {
  const formTask = document.getElementById("tambahhtask");
  if (!formTask) return;

  formTask.addEventListener("submit", function (e) {
    e.preventDefault();

    const missingFields = [];
    const invalidFields = [];

    const fields = [
      {
        id: "task",
        label: "Judul Task",
        regex: /^[a-zA-Z0-9 @]+$/,
        errorMsg: "Task hanya boleh berisi huruf, angka, spasi, dan @"
      },
      {
        id: "keterangan",
        label: "Keterangan Task",
        regex: /^[a-zA-Z0-9 @]+$/,
        errorMsg: "Keterangan hanya boleh berisi huruf, angka, spasi, dan @"
      },
      {
        id: "deadline",
        label: "Deadline",
        regex: /.+/,
        errorMsg: "Deadline harus diisi"
      },
      {
        id: "prioritas",
        label: "Prioritas",
        regex: /.+/,
        errorMsg: "Prioritas harus diisi"
      }
    ];

    fields.forEach((field) => {
      const input = formTask.querySelector("#" + field.id);
      const value = input?.value.trim();
      if (!value) {
        missingFields.push(field.label);
      } else if (field.regex && !field.regex.test(value)) {
        invalidFields.push(field.errorMsg);
      }
    });

    if (missingFields.length > 0) {
      Swal.fire({
        icon: "warning",
        title: "Field belum terisi!",
        html: "<strong>Field kosong:</strong><br>" + missingFields.join(", "),
        confirmButtonText: "Mengerti"
      });
      return;
    } else if (invalidFields.length > 0) {
      Swal.fire({
        icon: "warning",
        title: "Field tidak valid!",
        html: "<strong>Field tidak valid:</strong><br>" + invalidFields.join("<br>"),
        confirmButtonText: "Mengerti"
      });
      return;
    }

    const formData = new FormData(formTask);

    fetch(window.routes.taskStore, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          const task = data.task;

          const newTaskHtml = `
          <div class="col-12 col-md-6 mb-3">
            <div class="card priority-${task.prioritas} todo-card"
                 data-priority="${task.prioritas}"
                 data-deadline="${task.deadline}"
                 data-task-id="${task.id_task}"
                 data-created="${task.created_at}"
                 data-status-task="${task.status_task}">
              <div class="card-header bg-primary text-white">
                <div class="row w-100">
                  <div class="col-12">
                    <h3 class="task-title mb-0"><span class="task-text">${task.judul_task}</span></h3>
                  </div>
                  <div class="col-6">
                    <small class="task-date text-light">Tanggal Pembuatan: ${task.created_at}</small>
                  </div>
                  <div class="col-6 text-end">
                    <span class="badge bg-priority-medium">Prioritas: ${task.prioritas}</span>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="subtask-info mb-3">
                  <h6 class="mb-2">Subtask:</h6>
                  <ul class="list-group list-group-flush overflow-auto" style="max-height: 200px;"></ul>
                </div>
                <hr>
                <div class="due-date">
                  <span class="d-block mb-2">Waktu Tenggat: ${task.deadline}</span>
                  <span class="d-block mb-2">Prioritas: ${task.prioritas}</span>
                  <span class="d-block mb-2">Status Task: ${task.status_task}</span>
                </div>
              </div>
              <div class="card-footer bg-light d-flex justify-content-between align-items-center">
                <div class="btn-group gap-2">
                  <button type="button" class="btn btn-outline-primary btn-sm tambah-subtask" data-id="${task.id_task}">Tambah Subtask</button>
                  <button type="button" class="btn btn-sm done-btn ${task.status_task === 'selesai' ? 'btn-warning' : 'btn-primary'}" data-id="${task.id_task}" data-status="${task.status_task}">
                    ${task.status_task === 'selesai' ? 'Batalkan' : 'Selesai'}
                  </button>
                  <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="${task.id_task}">Hapus</button>
                </div>
                <button type="button" class="btn btn-primary btn-sm edit-btn"
                        data-task="${task.judul_task}"
                        data-keterangan="${task.keterangan_task}"
                        data-deadline="${task.deadline}"
                        data-task-id="${task.id_task}"
                        data-status="${data.task.status_task}">
                  Edit Task
                </button>
              </div>
            </div>
          </div>`;

          const todoList = document.getElementById("todo-list");
          if (todoList) {
            todoList.insertAdjacentHTML("beforeend", newTaskHtml);
          }
          
          if (data.subtask) {
    // Cari card yang baru
    const card = todoList.querySelector(`.todo-card[data-task-id="${task.id_task}"]`);
    const ul   = card.querySelector(".subtask-info ul");
    const liHtml = `
      <li class="list-group-item listSubtask">
        <label>
        <p class="subtask-desc mb-0">
          Keterangan: ${data.subtask.keterangan_subtask}
        </p>
      </li>`;
    ul.insertAdjacentHTML("beforeend", liHtml);
  }

          formTask.reset();
          const modal = bootstrap.Modal.getInstance(document.getElementById("tambahTaskModal"));
          if (modal) modal.hide();

          Swal.fire({
            icon: "success",
            title: "Berhasil!",
            text: "Task berhasil ditambahkan.",
            confirmButtonText: "Oke"
          });
        } else {
          Swal.fire({
            icon: "error",
            title: "Gagal!",
            text: "Terjadi kesalahan saat menambah task.",
            confirmButtonText: "Mengerti"
          });
        }
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Error!",
          text: "Terjadi kesalahan: " + error,
          confirmButtonText: "Mengerti"
        });
      });
  });

  // EVENT DELEGATION
  /*document.getElementById("todo-list").addEventListener("click", function (e) {
    const target = e.target;

    if (target.classList.contains("delete-btn")) {
      const id = target.dataset.id;
      console.log("Hapus task", id);
      // Lakukan aksi delete di sini
    }

    if (target.classList.contains("done-btn")) {
      const id = target.dataset.id;
      const currentStatus = target.dataset.status;
      console.log("Toggle status task", id, currentStatus);
      // Lakukan aksi update status
    }

    if (target.classList.contains("edit-btn")) {
      const id = target.dataset.taskId;
      const title = target.dataset.task;
      const desc = target.dataset.keterangan;
      const deadline = target.dataset.deadline;
      console.log("Edit task", { id, title, desc, deadline });
      // Isi form edit dan tampilkan modal edit
    }
  });*
}*/

document.addEventListener("DOMContentLoaded", function () {
  initTaskForm();
});