function initTaskSort() {
  const sortTasksDropdown = document.getElementById("sortTasksDropdown");
  const sortTasksItems = document.querySelectorAll("#sortTasksDropdown + .dropdown-menu .dropdown-item");
  const sortOrderDropdown = document.getElementById("sortOrderDropdown");
  const sortOrderItems = document.querySelectorAll("#sortOrderDropdown + .dropdown-menu .dropdown-item");
  const todoList = document.getElementById("todo-list");

  if (!sortTasksDropdown || !sortOrderDropdown || !todoList ||
      sortTasksItems.length === 0 || sortOrderItems.length === 0) return;

  let selectedSortBy = "title"; // Nilai default
  let selectedSortOrder = "asc"; // Nilai default

  // Event listener untuk dropdown sort tasks
  sortTasksItems.forEach(item => {
    item.addEventListener("click", function(e) {
      e.preventDefault();
      selectedSortBy = this.getAttribute("data-value");
      sortTasksDropdown.setAttribute("title", "Sort: " + this.textContent);
      sortTasks();
    });
  });

  // Event listener untuk dropdown sort order
  sortOrderItems.forEach(item => {
    item.addEventListener("click", function(e) {
      e.preventDefault();
      selectedSortOrder = this.getAttribute("data-value");
      sortOrderDropdown.setAttribute("title", "Order: " + this.textContent);
      sortTasks();
    });
  });

  function sortTasks() {
    // Hapus pesan "no-task-msg" jika ada, agar tidak ikut tersortir
    const existingMsg = document.getElementById("no-task-msg");
    if (existingMsg) existingMsg.remove();

    const containers = Array.from(todoList.children)
      .filter(container => container.id !== "no-task-msg");

    containers.sort((a, b) => {
      const cardA = a.querySelector(".todo-card");
      const cardB = b.querySelector(".todo-card");

      if (!cardA || !cardB) return 0;
      let compare = 0;

      if (selectedSortBy === "title") {
        const titleA = (a.querySelector(".task-text") || { textContent: "" }).textContent.trim().toLowerCase();
        const titleB = (b.querySelector(".task-text") || { textContent: "" }).textContent.trim().toLowerCase();
        compare = titleA.localeCompare(titleB);
      } else if (selectedSortBy === "priority") {
        // Misalnya urutannya: tinggi > sedang > rendah.
        const priorityOrder = { "tinggi": 1, "sedang": 2, "rendah": 3 };
        const priorityA = (cardA.getAttribute("data-priority") || "").toLowerCase();
        const priorityB = (cardB.getAttribute("data-priority") || "").toLowerCase();
        compare = (priorityOrder[priorityA] || 99) - (priorityOrder[priorityB] || 99);
      } else if (selectedSortBy === "deadline") {
        const deadlineA = new Date(cardA.getAttribute("data-deadline"));
        const deadlineB = new Date(cardB.getAttribute("data-deadline"));
        compare = deadlineA - deadlineB;
      } else if (selectedSortBy === "created") {
        const createdA = new Date(cardA.getAttribute("data-created"));
        const createdB = new Date(cardB.getAttribute("data-created"));
        compare = createdA - createdB;
      }

      return selectedSortOrder === "asc" ? compare : -compare;
    });

    // Bersihkan todoList dan masukkan kembali container yang telah diurutkan
    todoList.innerHTML = "";
    containers.forEach(container => {
      todoList.appendChild(container);
    });

    // Jika tidak ada task sama sekali, tampilkan pesan
    if (containers.length === 0 || containers.every(c => c.style.display === "none")) {
      let noMsg = document.createElement("p");
      noMsg.id = "no-task-msg";
      //noMsg.textContent = "Gagal melakukan sortir. Anda belum memiliki task";
      noMsg.textContent = "Task yang anda cari tidak ada";
      noMsg.classList.add("text-center", "mt-3", "text-muted");
      todoList.appendChild(noMsg);
    }
  }
}

document.addEventListener("DOMContentLoaded", function () {
  initTaskSort();
});