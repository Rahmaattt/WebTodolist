    /**
     * Modul: Notifikasi Toast
     * Menampilkan notifikasi "Signed in successfully" menggunakan SweetAlert2.
     */
function initToastNotification() {
      const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.onmouseenter = Swal.stopTimer;
          toast.onmouseleave = Swal.resumeTimer;
        }
      });
      Toast.fire({
        icon: "success",
        title: "Login telah berhasil"
      });
    }
    
document.addEventListener("DOMContentLoaded", function () {
  initToastNotification();
});