export function initTema() {
      // Ambil elemen tombol
      const themeButton = document.getElementById('Tema');
      // Periksa apakah pengguna sebelumnya pernah menyimpan preferensi tema di localStorage
      // Jika localStorage berisi "dark", maka atur isDarkMode = true, sebaliknya false
      let isDarkMode = localStorage.getItem('theme') === 'dark';
       // Fungsi untuk mengatur tema sesuai nilai isDarkMode
      function setTheme() {
        if (isDarkMode) {
           // Tambah class Dark Mode pada body
          document.body.classList.add('bg-dark', 'text-white');
          // Ubah teks tombol
          themeButton.textContent = "Light Mode";
        } else {
          // Hapus class Dark Mode pada body
          document.body.classList.remove('bg-dark', 'text-white');
          // Ubah teks tombol
          themeButton.textContent = "Dark Mode";
           
        }
      }
      // Event listener ketika tombol di-klik
      themeButton.addEventListener('click', function() {
        // Balik nilai isDarkMode
        isDarkMode = !isDarkMode;
        // Simpan preferensi ke localStorage
        localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
        // Set ulang tema
        setTheme();
      });
        // Panggil sekali di awal agar tema sesuai preferensi tersimpan
      setTheme();
    }