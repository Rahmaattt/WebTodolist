function initSubtaskForm() {
  var formSubtask = document.getElementById("formTambahSubtask");
  if (!formSubtask) return;

  formSubtask.addEventListener("submit", function (e) {
    e.preventDefault();

    var missingFields = [];
    var invalidFields = [];

    var fields = [
      {
        id: "judul_subtask",
        label: "Judul Subtask",
        regex: /^[a-zA-Z0-9 ]+$/,
        errorMsg: "Judul Subtask hanya boleh berisi huruf, angka, dan spasi"
      },
      {
        id: "keterangan_subtask",
        label: "Keterangan Subtask",
        regex: /^[a-zA-Z0-9 ]+$/,
        errorMsg: "Keterangan hanya boleh berisi huruf, angka, dan spasi"
      }
    ];

    fields.forEach(function (field) {
      var input = formSubtask.querySelector('#' + field.id);
      if (input) {
        var value = input.value.trim();
        if (value === "") {
          missingFields.push(field.label);
        } else if (!field.regex.test(value)) {
          invalidFields.push(field.errorMsg);
        }
      }
    });

    if (missingFields.length > 0) {
      Swal.fire({
        icon: "warning",
        title: "Field belum terisi!",
        html: "<strong>Field kosong:</strong><br>" + missingFields.join(", "),
        confirmButtonText: "Mengerti"
      });
      return;
    } else if (invalidFields.length > 0) {
      Swal.fire({
        icon: "warning",
        title: "Field tidak valid!",
        html: "<strong>Field tidak valid:</strong><br>" + invalidFields.join("<br>"),
        confirmButtonText: "Mengerti"
      });
      return;
    }

    var formData = new FormData(formSubtask);

    // Menggunakan URL route yang didefinisikan di file Blade melalui window.routes
    fetch(window.routes.subtaskStore, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then(response => response.json())
      .then(function (data) {
        if (data.success) {
          Swal.fire({
            icon: "success",
            title: "Berhasil!",
            text: "Subtask berhasil ditambahkan.",
            confirmButtonText: "Mengerti"
          });

          var card = document.querySelector('.todo-card[data-task-id="' + data.subtask.id_task + '"]');
          if (card) {
            var ul = card.querySelector('.subtask-info ul');
            if (ul) {
              var newSubtaskHtml = `
                <li class="list-group-item listSubtask">
                  <label>
                    <input type="checkbox" class="subtask-checkbox" data-id="${data.subtask.id_subtask}" ${data.subtask.status_subtask === 'selesai' ? 'checked' : ''}>
                    ${data.subtask.judul_subtask}
                  </label>
                  <p class="subtask-desc mb-0">Keterangan: ${data.subtask.keterangan_subtask}</p>
                  <button type="button" class="btn btn-outline-primary btn-sm update-subtask">Edit Subtask</button>
                  <button type="button" class="btn btn-outline-danger btn-sm delete-subtask" data-id="${data.subtask.id_subtask}">Hapus Subtask</button>
                </li>`;
              ul.insertAdjacentHTML('beforeend', newSubtaskHtml);
            }
          }

          formSubtask.reset();
          var modalEl = document.getElementById("modalTambahSubtask");
          var modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire({
            icon: "error",
            title: "Gagal!",
            text: "Terjadi kesalahan saat menambah subtask.",
            confirmButtonText: "Mengerti"
          });
        }
      })
      .catch(function (error) {
        Swal.fire({
          icon: "error",
          title: "Error!",
          text: "Terjadi kesalahan pada AJAX: " + error,
          confirmButtonText: "Mengerti"
        });
      });
  });
}

document.addEventListener("DOMContentLoaded", function(){
  initSubtaskForm();
});


    /**
     * Modul: Form Tambah Subtask (AJAX)
     */
    /*function initSubtaskForm() {
      var formSubtask = document.getElementById("formTambahSubtask");
      if (!formSubtask) return;
      formSubtask.addEventListener("submit", function(e) {
        e.preventDefault();
        var formData = new FormData(formSubtask);
        fetch("{{ route('subtask.store') }}", {
            method: "POST",
            body: formData,
            headers: {
              "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
              "Accept": "application/json"
            }
          })
          .then(response => response.text())
          .then(function(text) {
            try {
              var data = JSON.parse(text);
              if (data.success) {
                Swal.fire("Subtask berhasil ditambahkan!", "", "success");
                var card = document.querySelector('.todo-card[data-task-id="' + data.subtask.id_task + '"]');
              if (card) {
                // Cari container ul dalam div subtask-info
                var ul = card.querySelector('.subtask-info ul');
                if (ul) {
                  var newSubtaskHtml = `
                    <li class="list-group-item listSubtask">
                      <label>
                        <input type="checkbox" class="subtask-checkbox" data-id="${data.subtask.id_subtask}" ${data.subtask.status_subtask === 'selesai' ? 'checked' : ''}>
                    ${data.subtask.judul_subtask}
                      </label>
                      <p class="subtask-desc mb-0">Keterangan: ${data.subtask.keterangan_subtask}</p>
                    </li>
                    `;
                    // Tambahkan subtask baru di akhir daftar
                    ul.insertAdjacentHTML('beforeend', newSubtaskHtml);
                  }
                }
                formSubtask.reset();
                var modalEl = document.getElementById("modalTambahSubtask");
                var modalInstance = bootstrap.Modal.getInstance(modalEl);
                if (modalInstance) modalInstance.hide();
              } else {
                Swal.fire("Terjadi kesalahan saat menambah subtask.", "", "error");
              }
            } catch (e) {
              Swal.fire("Error parsing JSON: " + e, "", "error");
            }
          })
          .catch(function(error) {
            Swal.fire("Error AJAX: " + error, "", "error");
          });
      });
    }*/