function initNavbarAdjustment() {
      function adjustNavbar() {
        var navbarContent = document.getElementById('navbarContent');
        var navbarToggler = document.querySelector('.navbar-toggler');
        if (!navbarContent || !navbarToggler) return;
        if (window.innerWidth >= 576) {
          navbarContent.classList.add('show');
          navbarToggler.style.display = 'none';
        } else {
          navbarContent.classList.remove('show');
          navbarToggler.style.display = '';
        }
      }
      window.addEventListener('load', adjustNavbar);
      window.addEventListener('resize', adjustNavbar);
    }
    
document.addEventListener("DOMContentLoaded", function () {
  initNavbarAdjustment();
});