// public/js/main.js
import { initTaskSort } from './initTaskSort.js';
import { initTaskFilter } from './initTaskFilter.js';
import { initTema } from './initTema.js';
import { initBadge } from './initBadge.js';
import { initNavbarAdjustment } from './initNavbarAdjustment.js';
import { initDatetimeLocal } from './initDatetimeLocal.js';
import { initToastNotification } from ' ./initToastNotification.js';
import { initDeadlineChecker } from './initDeadlineChecker.js';
//import { initTaskStatusUpdater } from './initTaskStatusUpdater.js';
import { initDeleteConfirmation } from './initDeleteConfirmation.js';
import { initSubtaskForm } from './initSubtaskForm.js';
import { initSubtaskCheckboxes } from './initSubtaskCheckboxes.js';
import { initTaskUpdateForm } from './initTaskUpdateForm.js';
import { initTaskUpdateForm } from './initSubtaskUpdateForm.js';

document.addEventListener("DOMContentLoaded", () => {
  alert("DOMContentLoaded: Inisialisasi awal dijalankan!");
  initTaskSort();
  initTaskFilter();
  initTema();
  initBadge();
  initNavbarAdjustment();
  initDatetimeLocal();
  initDeadlineChecker();
  initDeleteConfirmation();
  initSubtaskForm();
  initSubtaskCheckboxes();
  initTaskUpdateForm();
  initSubtaskUpdateForm();
});

//const targetNode = document.querySelector(".task-list") || document.body;

/*const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    alert("MutationObserver: Perubahan terdeteksi!");

    if (mutation.type === "childList") {
      alert("MutationObserver: childList berubah!");
    } 
    if (mutation.type === "attributes") {
      alert("MutationObserver: attribute berubah di " + mutation.target.tagName);
    } 
    if (mutation.type === "characterData") {
      alert("MutationObserver: characterData berubah!");
    }

    initTaskSort();
    initTaskFilter();
    initTema();
    initBadge();
    initNavbarAdjustment();
    initDatetimeLocal();
    initDeadlineChecker();
    initDeleteConfirmation();
    initSubtaskForm();
  });
});

// Observasi perubahan dalam bagian spesifik dari halaman
observer.observe(targetNode, { 
  childList: true, 
  subtree: true, 
  attributes: true, 
  characterData: true 
});*/
