function initTaskFilter() {
  const filterDropdown = document.getElementById("filterDropdown");
  const filterItems = document.querySelectorAll("#filterDropdown + .dropdown-menu .dropdown-item");
  const todoList = document.getElementById("todo-list");
  
  if (!filterDropdown || !todoList || filterItems.length === 0) return;
  
  let selectedPriority = "all"; // Nilai default

  filterItems.forEach(item => {
    item.addEventListener("click", function(e) {
      e.preventDefault();
      selectedPriority = this.getAttribute("data-value");
      // Update title (atau tooltip) tombol filter
      filterDropdown.setAttribute("title", "Filter: " + this.textContent);
      applyFilter();
    });
  });

  function applyFilter() {
    const containers = Array.from(todoList.children);
    let visibleCount = 0;

    containers.forEach(container => {
      // Abaikan elemen pesan jika ada
      if (container.id === "no-task-msg") return;
      
      const card = container.querySelector(".todo-card");
      const cardPriority = card ? card.getAttribute("data-priority") : null;
      if (selectedPriority === "all" || cardPriority === selectedPriority) {
        container.style.display = "";
        visibleCount++;
      } else {
        container.style.display = "none";
      }
    });

    // Jika tidak ada task yang terlihat, tampilkan pesan
    let noTaskMsg = document.getElementById("no-task-msg");
    if (visibleCount === 0) {
      if (!noTaskMsg) {
        noTaskMsg = document.createElement("p");
        noTaskMsg.id = "no-task-msg";
        //noTaskMsg.textContent = "Gagal melakukan filter. Anda belum memiliki task";
        noTaskMsg.textContent = "Task yang anda cari tidak ada";
        noTaskMsg.classList.add("text-center", "mt-3", "text-muted");
        todoList.appendChild(noTaskMsg);
      }
    } else {
      // Jika ada task, hapus pesan jika ada
      if (noTaskMsg) noTaskMsg.remove();
    }
  }
}

document.addEventListener("DOMContentLoaded", function () {
  initTaskFilter();
});