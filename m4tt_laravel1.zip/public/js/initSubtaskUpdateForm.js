/*function initSubtaskUpdateForm() {
  var formUpdateSubtask = document.getElementById("formUpdateSubtask");
  if (!formUpdateSubtask) return;
  
  formUpdateSubtask.addEventListener("submit", function (e) {
    e.preventDefault();

    // Ambil elemen input dan textarea dari form update
    var inputJudul = formUpdateSubtask.querySelector('input[name="judul_subtask"]');
    var inputKeterangan = formUpdateSubtask.querySelector('textarea[name="keterangan_subtask"]');

    // Ambil nilai asli dari atribut data-* yang di-set dari Laravel (gunakan Blade untuk set nilai awal)
    var originalJudul = inputJudul.dataset.originalValue || inputJudul.defaultValue.trim();
    var originalKeterangan = inputKeterangan.dataset.originalValue || inputKeterangan.defaultValue.trim();

    var newJudul = inputJudul.value.trim();
    var newKeterangan = inputKeterangan.value.trim();

    console.log("Original Judul:", originalJudul);
    console.log("New Judul:", newJudul);
    console.log("Original Keterangan:", originalKeterangan);
    console.log("New Keterangan:", newKeterangan);

    // Bandingkan nilai lama dengan nilai baru
    var changedFields = [];
    if (newJudul !== originalJudul) {
      changedFields.push("Judul Subtask");
    }
    if (newKeterangan !== originalKeterangan) {
      changedFields.push("Keterangan Subtask");
    }

    // Jika tidak ada perubahan, tampilkan notifikasi dan hentikan proses
    if (changedFields.length === 0) {
      Swal.fire({
        icon: "info",
        title: "Tidak ada perubahan",
        confirmButtonText: "Mengerti"
      });
      return;
    }

    var formData = new FormData(formUpdateSubtask);

    fetch("{{ route('subtask.updateSubtask') }}", {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then(response => response.json())
      .then(function (data) {
        if (data.success) {
          // Tentukan pesan notifikasi berdasarkan field yang diubah
          var message = changedFields.length === 2 
            ? "Subtask berhasil diedit" 
            : changedFields[0] + " berhasil diedit";

          Swal.fire({
            icon: "success",
            title: message,
            confirmButtonText: "Mengerti"
          });

          // Perbarui tampilan subtask pada halaman
          var card = document.querySelector('.todo-card[data-task-id="' + data.subtask.id_task + '"]');
          if (card) {
            var subtaskItem = card.querySelector('.listSubtask input.subtask-checkbox[data-id="' + data.subtask.id_subtask + '"]');
            if (subtaskItem) {
              var listItem = subtaskItem.closest('.listSubtask');
              if (listItem) {
                listItem.innerHTML = `
                  <label>
                    ${data.subtask.judul_subtask}
                  </label>
                  <p class="subtask-desc mb-0">Keterangan: ${data.subtask.keterangan_subtask}</p>
                `;
              }
            }
          }

          // Reset form dan sembunyikan modal update
          formUpdateSubtask.reset();
          var modalEl = document.getElementById("modalUpdateSubtask");
          var modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire({
            icon: "error",
            title: "Terjadi kesalahan saat mengupdate subtask.",
            confirmButtonText: "Mengerti"
          });
        }
      })
      .catch(function (error) {
        Swal.fire({
          icon: "error",
          title: "Error AJAX: " + error,
          confirmButtonText: "Mengerti"
        });
      });
  });
}*/
/*function initSubtaskUpdateForm() {
  const formUpdateSubtask = document.getElementById("formUpdateSubtask");
  if (!formUpdateSubtask) return;
  
  formUpdateSubtask.addEventListener("submit", function (e) {
    e.preventDefault();

    // Ambil elemen input dan textarea dari form update
    const inputJudul = formUpdateSubtask.querySelector('input[name="judul_subtask"]');
    const inputKeterangan = formUpdateSubtask.querySelector('textarea[name="keterangan_subtask"]');

    // Ambil nilai asli dari atribut data-* yang di-set dari Laravel
    const originalJudul = inputJudul.dataset.originalValue || inputJudul.defaultValue.trim();
    const originalKeterangan = inputKeterangan.dataset.originalValue || inputKeterangan.defaultValue.trim();

    const newJudul = inputJudul.value.trim();
    const newKeterangan = inputKeterangan.value.trim();

    console.log("Original Judul:", originalJudul);
    console.log("New Judul:", newJudul);
    console.log("Original Keterangan:", originalKeterangan);
    console.log("New Keterangan:", newKeterangan);

    // Bandingkan nilai lama dengan nilai baru
    const changedFields = [];
    if (newJudul !== originalJudul) {
      changedFields.push("Judul Subtask");
    }
    if (newKeterangan !== originalKeterangan) {
      changedFields.push("Keterangan Subtask");
    }

    // Jika tidak ada perubahan, tampilkan notifikasi dan hentikan proses
    if (changedFields.length === 0) {
      Swal.fire({
        icon: "info",
        title: "Tidak ada perubahan",
        confirmButtonText: "Mengerti"
      });
      return;
    }

    const formData = new FormData(formUpdateSubtask);

    fetch(window.routes.updateSubtaskForm, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then(response => response.json())
      .then(function (data) {
        if (data.success) {
          // Tentukan pesan notifikasi berdasarkan field yang diubah
          const message = changedFields.length === 2 
            ? "Subtask berhasil diedit" 
            : changedFields[0] + " berhasil diedit";

          Swal.fire({
            icon: "success",
            title: message,
            confirmButtonText: "Mengerti"
          });

          // Perbarui tampilan subtask pada halaman
          const card = document.querySelector(`.todo-card[data-task-id="${data.subtask.id_task}"]`);
          if (card) {
            const subtaskItem = card.querySelector(`.listSubtask input.subtask-checkbox[data-id="${data.subtask.id_subtask}"]`);
            if (subtaskItem) {
              const listItem = subtaskItem.closest('.listSubtask');if (listItem) {
  listItem.innerHTML = `
    <input type="checkbox" class="form-check-input me-2 subtask-checkbox" data-id="${data.subtask.id_subtask}" />
    <label class="form-check-label me-auto">
      ${data.subtask.judul_subtask}
    </label>
    <div class="d-flex flex-column ms-4">
      <p class="subtask-desc mb-0">Keterangan: ${data.subtask.keterangan_subtask}</p>
      <div class="mt-2">
        <button type="button" class="btn btn-sm btn-outline-primary me-1 edit-subtask-btn" 
                data-id="${data.subtask.id_subtask}"
                data-task-id="${data.subtask.id_task}"
                data-judul="${data.subtask.judul_subtask}"
                data-keterangan="${data.subtask.keterangan_subtask}">
          Edit
        </button>
        <button type="button" class="btn btn-sm btn-outline-danger delete-subtask-btn" data-id="${data.subtask.id_subtask}">
          Hapus
        </button>
      </div>
    </div>
  `;
}

              
            }
          }

          // Reset form dan sembunyikan modal update
          formUpdateSubtask.reset();
          const modalEl = document.getElementById("modalUpdateSubtask");
          const modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire({
            icon: "error",
            title: "Terjadi kesalahan saat mengupdate subtask.",
            confirmButtonText: "Mengerti"
          });
        }
      })
      .catch(function (error) {
        Swal.fire({
          icon: "error",
          title: "Error AJAX: " + error,
          confirmButtonText: "Mengerti"
        });
      });
  });
}*/
/*function initSubtaskUpdateForm() {
  const formUpdateSubtask = document.getElementById("formUpdateSubtask");
  if (!formUpdateSubtask) return;

  formUpdateSubtask.addEventListener("submit", function (e) {
    e.preventDefault();

    const inputJudul = formUpdateSubtask.querySelector('input[name="judul_subtask"]');
    const inputKeterangan = formUpdateSubtask.querySelector('textarea[name="keterangan_subtask"]');

    const originalJudul = inputJudul.dataset.originalValue || inputJudul.defaultValue.trim();
    const originalKeterangan = inputKeterangan.dataset.originalValue || inputKeterangan.defaultValue.trim();

    const newJudul = inputJudul.value.trim();
    const newKeterangan = inputKeterangan.value.trim();

    const changedFields = [];
    if (newJudul !== originalJudul) changedFields.push("Judul Subtask");
    if (newKeterangan !== originalKeterangan) changedFields.push("Keterangan Subtask");

    if (changedFields.length === 0) {
      Swal.fire({
        icon: "info",
        title: "Tidak ada perubahan",
        confirmButtonText: "Mengerti"
      });
      return;
    }

    const formData = new FormData(formUpdateSubtask);

    fetch(window.routes.updateSubtaskForm, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then(response => response.json())
      .then(function (data) {
        if (data.success) {
          const message = changedFields.length === 2 
            ? "Subtask berhasil diedit" 
            : changedFields[0] + " berhasil diedit";

          Swal.fire({
            icon: "success",
            title: message,
            confirmButtonText: "Mengerti"
          });

          // Update elemen di halaman
          const card = document.querySelector(`.todo-card[data-task-id="${data.subtask.id_task}"]`);
          if (card) {
            const subtaskItem = card.querySelector(`.listSubtask input.subtask-checkbox[data-id="${data.subtask.id_subtask}"]`);
            if (subtaskItem) {
              const listItem = subtaskItem.closest('.listSubtask');
              if (listItem) {
                const label = listItem.querySelector('label');
                const desc = listItem.querySelector('.subtask-desc');
                const editBtn = listItem.querySelector('.edit-subtask-btn');

                if (label) label.textContent = data.subtask.judul_subtask;
                if (desc) desc.textContent = 'Keterangan: ' + data.subtask.keterangan_subtask;
                if (editBtn) {
                  editBtn.dataset.judul = data.subtask.judul_subtask;
                  editBtn.dataset.keterangan = data.subtask.keterangan_subtask;
                }
              }
            }
          }

          // Reset dan tutup modal
          formUpdateSubtask.reset();
          const modalEl = document.getElementById("modalUpdateSubtask");
          const modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire({
            icon: "error",
            title: "Terjadi kesalahan saat mengupdate subtask.",
            confirmButtonText: "Mengerti"
          });
        }
      })
      .catch(function (error) {
        Swal.fire({
          icon: "error",
          title: "Error AJAX: " + error,
          confirmButtonText: "Mengerti"
        });
      });
  });
}*/
function initSubtaskUpdateForm() {
  const formUpdateSubtask = document.getElementById("formUpdateSubtask");
  if (!formUpdateSubtask) return;
  
  formUpdateSubtask.addEventListener("submit", function (e) {
    e.preventDefault();

    // Ambil elemen input dan textarea dari form update
    const inputJudul = formUpdateSubtask.querySelector('input[name="judul_subtask"]');
    const inputKeterangan = formUpdateSubtask.querySelector('textarea[name="keterangan_subtask"]');

    // Ambil nilai asli dari atribut data-* yang sudah diset (atau defaultValue)
    const originalJudul = inputJudul.dataset.originalValue || inputJudul.defaultValue.trim();
    const originalKeterangan = inputKeterangan.dataset.originalValue || inputKeterangan.defaultValue.trim();

    const newJudul = inputJudul.value.trim();
    const newKeterangan = inputKeterangan.value.trim();

    console.log("Original Judul:", originalJudul);
    console.log("New Judul:", newJudul);
    console.log("Original Keterangan:", originalKeterangan);
    console.log("New Keterangan:", newKeterangan);

    // Bandingkan nilai lama dengan nilai baru
    const changedFields = [];
    if (newJudul !== originalJudul) {
      changedFields.push("Judul Subtask");
    }
    if (newKeterangan !== originalKeterangan) {
      changedFields.push("Keterangan Subtask");
    }

    // Jika tidak ada perubahan, tampilkan notifikasi dan hentikan proses
    if (changedFields.length === 0) {
      Swal.fire({
        icon: "info",
        title: "Tidak ada perubahan",
        confirmButtonText: "Mengerti"
      });
      return;
    }

    const formData = new FormData(formUpdateSubtask);

    fetch(window.routes.updateSubtaskForm, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then(response => response.json())
      .then(function (data) {
        if (data.success) {
          // Tentukan pesan notifikasi berdasarkan field yang diubah
          const message = changedFields.length === 2 
            ? "Subtask berhasil diedit" 
            : changedFields[0] + " berhasil diedit";

          Swal.fire({
            icon: "success",
            title: message,
            confirmButtonText: "Mengerti"
          });

          // Perbarui tampilan subtask pada halaman tanpa mengganti seluruh innerHTML,
          // dengan mengubah nilai elemen secara langsung agar event listener tetap aktif.
          const card = document.querySelector(`.todo-card[data-task-id="${data.subtask.id_task}"]`);
          if (card) {
            // Cari subtask yang ingin diupdate
            const subtaskItem = card.querySelector(`.listSubtask input.subtask-checkbox[data-id="${data.subtask.id_subtask}"]`);
            if (subtaskItem) {
              const listItem = subtaskItem.closest('.listSubtask');
              if (listItem) {
                // Asumsikan strukturnya seperti ini:
                // <li class="listSubtask">
                //   <label> <input ...> Judul Subtask </label>
                //   <p class="subtask-desc mb-0">Keterangan: ...</p>
                //   <button type="button" class="btn btn-outline-primary btn-sm update-subtask">Edit Subtask</button>
                //   <button type="button" class="btn btn-outline-danger btn-sm delete-subtask" data-id="...">Hapus Subtask</button>
                // </li>
                const labelEl = listItem.querySelector('label');
                const descEl = listItem.querySelector('.subtask-desc');
                const editBtn = listItem.querySelector('.edit-subtask-btn');
                // Jika tombol edit tidak ada, jika kamu pakai class update-subtask, sesuaikan
                // Misalnya:
                const updateBtn = listItem.querySelector('.update-subtask');
                
                if (labelEl) {
                  // Ubah teks label—pastikan hanya mengubah teks setelah input
                  // Misalnya, jika label berisi input dan teks, kita bisa ambil childNodes
                  // Cara mudah: hilangkan input, set teks setelahnya, dan kembalikan input.
                  // Tetapi, solusi sederhana:
                  labelEl.innerHTML = `
                    <input type="checkbox" class="subtask-checkbox" data-id="${data.subtask.id_subtask}" ${data.subtask.status_subtask === 'selesai' ? 'checked' : ''}>
                    ${data.subtask.judul_subtask}
                  `;
                }
                if (descEl) {
                  descEl.textContent = 'Keterangan: ' + data.subtask.keterangan_subtask;
                }
                // Jika ada tombol edit, perbarui data-* pada tombol edit
                if (editBtn) {
                  editBtn.dataset.judul = data.subtask.judul_subtask;
                  editBtn.dataset.keterangan = data.subtask.keterangan_subtask;
                }
                // Jika kamu menggunakan tombol update-subtask sebagai pemicu, perbarui data-nya juga
                if (updateBtn) {
                  updateBtn.dataset.judul = data.subtask.judul_subtask;
                  updateBtn.dataset.keterangan = data.subtask.keterangan_subtask;
                }
              }
            }
          }

          // Setelah update berhasil, perbarui juga nilai asli (original) pada form update
          // agar pada update selanjutnya perbandingan menjadi benar.
          inputJudul.dataset.originalValue = data.subtask.judul_subtask;
          inputKeterangan.dataset.originalValue = data.subtask.keterangan_subtask;
          // Jika diperlukan, juga perbarui nilai default (defaultValue)
          inputJudul.defaultValue = data.subtask.judul_subtask;
          inputKeterangan.defaultValue = data.subtask.keterangan_subtask;

          // Reset form dan tutup modal update
          formUpdateSubtask.reset();
          const modalEl = document.getElementById("modalUpdateSubtask");
          const modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire({
            icon: "error",
            title: "Terjadi kesalahan saat mengupdate subtask.",
            confirmButtonText: "Mengerti"
          });
        }
      })
      .catch(function (error) {
        Swal.fire({
          icon: "error",
          title: "Error AJAX: " + error,
          confirmButtonText: "Mengerti"
        });
      });
  });
}


document.addEventListener("DOMContentLoaded", function(){
  initSubtaskUpdateForm();
});