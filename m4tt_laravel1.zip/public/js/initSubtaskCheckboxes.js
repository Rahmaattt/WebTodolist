/*function initSubtaskCheckboxes() {
  var checkboxes = document.querySelectorAll(".subtask-checkbox");

  checkboxes.forEach(function (checkbox) {
    var subtaskId = checkbox.getAttribute("data-id");
    if (!subtaskId) return;

    // Ambil status tersimpan dari localStorage
    var storedStatus = localStorage.getItem("subtask_" + subtaskId);
    checkbox.checked = storedStatus === "true";
    updateCheckboxStyle(checkbox, checkbox.checked);

    checkbox.addEventListener("change", function () {
      var isChecked = checkbox.checked;
      var newStatus = isChecked ? "selesai" : "belum_selesai";

      // Debugging: Cek status dan data yang akan dikirim
      alert("Mengubah status subtask ID " + subtaskId + " menjadi " + newStatus);

      fetch(window.routes.updateStatussub.replace(":id_subtask", subtaskId), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ status_subtask: newStatus })
      })
        .then(response => {
          alert("Response status: " + response.status); // Debugging: Cek status response
          return response.json();
        })
        .then(function (data) {
          alert("Response data: " + JSON.stringify(data)); // Debugging: Lihat response data

          if (data.success) {
            localStorage.setItem("subtask_" + subtaskId, checkbox.checked);
            updateCheckboxStyle(checkbox, checkbox.checked);
          } else {
            alert("Gagal mengupdate status subtask. Response gagal: " + JSON.stringify(data));
            checkbox.checked = !checkbox.checked;
            updateCheckboxStyle(checkbox, checkbox.checked);
          }
        })
        .catch(function (error) {
          alert("Error AJAX: " + error); // Debugging: Error dalam fetch request
        });
    });
  });

  function updateCheckboxStyle(checkbox, isChecked) {
        var li = checkbox.closest("li");
        if (!li) return;
        var label = li.querySelector("label");
        var desc = li.querySelector("p.subtask-desc");
        if (isChecked) {
          if (label) label.style.color = "gray";
          if (desc) desc.style.color = "gray";
          checkbox.disabled = true;
        } else {
          if (label) label.style.color = "";
          if (desc) desc.style.color = "";
        }
      }
    }*/

/*function initSubtaskCheckboxes() {
  var checkboxes = document.querySelectorAll(".subtask-checkbox");

  checkboxes.forEach(function (checkbox) {
    var subtaskId = checkbox.getAttribute("data-id");
    if (!subtaskId) return;

    // Ambil status tersimpan dari localStorage dan sesuaikan checked
    var storedStatus = localStorage.getItem("subtask_" + subtaskId);
    checkbox.checked = storedStatus === "true";
    updateCheckboxStyle(checkbox, checkbox.checked);

    checkbox.addEventListener("change", function () {
      var isChecked = checkbox.checked;
      var newStatus = isChecked ? "selesai" : "belum_selesai";

      fetch(window.routes.updateStatussub.replace(":id_subtask", subtaskId), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ status_subtask: newStatus })
      })
        .then(response => {
          return response.json();
        })
        .then(function (data) {
          if (data.success) {
            // Simpan ke localStorage sebagai string "true"/"false"
            localStorage.setItem("subtask_" + subtaskId, isChecked.toString());
            updateCheckboxStyle(checkbox, isChecked);
          } else {
            alert("Gagal mengupdate status subtask.");
            // Balikkan checkbox ke status sebelumnya jika gagal
            checkbox.checked = !isChecked;
            updateCheckboxStyle(checkbox, checkbox.checked);
          }
        })
        .catch(function (error) {
          alert("Error AJAX: " + error);
        });
    });
  });

  function updateCheckboxStyle(checkbox, isChecked) {
    var li = checkbox.closest("li");
    if (!li) return;
    var label = li.querySelector("label");
    var desc = li.querySelector("p.subtask-desc");
    if (isChecked) {
      if (label) label.style.color = "gray";
      if (desc) desc.style.color = "gray";
      checkbox.disabled = true;
    } else {
      if (label) label.style.color = "";
      if (desc) desc.style.color = "";
    }
  }
  
  updateCheckboxStyle();
}*/


/*function initSubtaskCheckboxes() {
  var checkboxes = document.querySelectorAll(".subtask-checkbox");

  checkboxes.forEach(function (checkbox) {
    var subtaskId = checkbox.getAttribute("data-id");
    if (!subtaskId) return;

    // Ambil status tersimpan dari localStorage
    var storedStatus = localStorage.getItem("subtask_" + subtaskId);
    checkbox.checked = storedStatus === "true";
    updateCheckboxStyle(checkbox, checkbox.checked);

    checkbox.addEventListener("change", function () {
      var isChecked = checkbox.checked;
      var newStatus = isChecked ? "selesai" : "belum_selesai";

      // Debugging: Cek status dan data yang akan dikirim
      alert("Mengubah status subtask ID " + subtaskId + " menjadi " + newStatus);

      fetch(window.routes.updateStatussub.replace(":id_subtask", subtaskId), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ status_subtask: newStatus })
      })
        .then(response => {
          alert("Response status: " + response.status); // Debugging: Cek status response
          return response.json();
        })
        .then(function (data) {
          alert("Response data: " + JSON.stringify(data)); // Debugging: Lihat response data

          if (data.success) {
            localStorage.setItem("subtask_" + subtaskId, checkbox.checked);
            updateCheckboxStyle(checkbox, checkbox.checked);
          } else {
            alert("Gagal mengupdate status subtask. Response gagal: " + JSON.stringify(data));
            checkbox.checked = !checkbox.checked;
            updateCheckboxStyle(checkbox, checkbox.checked);
          }
        })
        .catch(function (error) {
          alert("Error AJAX: " + error); // Debugging: Error dalam fetch request
        });
    });
  });

  function updateCheckboxStyle(checkbox, isChecked) {
        var li = checkbox.closest("li");
        if (!li) return;
        var label = li.querySelector("label");
        var desc = li.querySelector("p.subtask-desc");
        if (isChecked) {
          if (label) label.style.color = "gray";
          if (desc) desc.style.color = "gray";
          checkbox.disabled = true;
        } else {
          if (label) label.style.color = "";
          if (desc) desc.style.color = "";
        }
      }
    }*/
    
/****function initSubtaskCheckboxes() {
  var checkboxes = document.querySelectorAll(".subtask-checkbox");

  checkboxes.forEach(function (checkbox) {
    var subtaskId = checkbox.getAttribute("data-id");
    if (!subtaskId) return;

    // Ambil status tersimpan dari localStorage; jika tidak ada, default menjadi false.
    var storedStatus = localStorage.getItem("subtask_" + subtaskId);
    checkbox.checked = storedStatus === "true";
    updateCheckboxStyle(checkbox, checkbox.checked);

    checkbox.addEventListener("change", function () {
      var isChecked = checkbox.checked;
      var newStatus = isChecked ? "selesai" : "belum_selesai";

      // Lakukan fetch untuk update status ke backend
      fetch(window.routes.updateStatussub.replace(":id_subtask", subtaskId), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ status_subtask: newStatus })
      })
      .then(response => response.json())
      .then(function (data) {
        if (data.success) {
          // Simpan status terbaru ke localStorage
          localStorage.setItem("subtask_" + subtaskId, checkbox.checked);
          updateCheckboxStyle(checkbox, checkbox.checked);
        } else {
          // Jika gagal, balikkan nilai checkbox dan update tampilan
          checkbox.checked = !checkbox.checked;
          updateCheckboxStyle(checkbox, checkbox.checked);
          alert("Gagal mengupdate status subtask. " + JSON.stringify(data));
        }
      })
      .catch(function (error) {
        alert("Error AJAX: " + error);
      });
    });
  });

  // Fungsi update tampilan dengan menambahkan class "completed" pada <li>
  function updateCheckboxStyle(checkbox, isChecked) {
    var li = checkbox.closest("li");
    if (!li) return;
    if (isChecked) {
      li.classList.add("completed");
      // Jika diinginkan agar checkbox tidak bisa diubah kembali, aktifkan baris berikut:
      // checkbox.disabled = true;
    } else {
      li.classList.remove("completed");
      // checkbox.disabled = false;
    }
  }
}*/

/*function initSubtaskCheckboxes() {
      var checkboxes = document.querySelectorAll(".subtask-checkbox");
      checkboxes.forEach(function(checkbox) {
        var subtaskId = checkbox.getAttribute("data-id");
        if (!subtaskId) return;
        // Ambil status tersimpan dari localStorage
        var storedStatus = localStorage.getItem("subtask_" + subtaskId);
        checkbox.checked = storedStatus === "true";
        updateCheckboxStyle(checkbox, checkbox.checked);
        checkbox.addEventListener("change", function() {
          var isChecked = checkbox.checked;
          var newStatus = isChecked ? "selesai" : "belum_selesai";
          fetch(`/subtask/update/${subtaskId}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({ status_subtask: newStatus })
          })
            .then(response => response.text())
            .then(function(text) {
              try {
                var data = JSON.parse(text);
                if (data.success) {
                  localStorage.setItem("subtask_" + subtaskId, checkbox.checked);
                  updateCheckboxStyle(checkbox, checkbox.checked);
                } else {
                  alert("Gagal mengupdate status subtask");
                  checkbox.checked = !checkbox.checked;
                  updateCheckboxStyle(checkbox, checkbox.checked);
                }
              } catch (e) {
                alert("Error parsing JSON: " + e);
              }
            })
            .catch(function(error) {
              alert("Error AJAX: " + error);
            });
        });
      });

      function updateCheckboxStyle(checkbox, isChecked) {
        var li = checkbox.closest("li");
        if (!li) return;
        var label = li.querySelector("label");
        var desc = li.querySelector("p.subtask-desc");
        if (isChecked) {
          if (label) label.style.color = "gray";
          if (desc) desc.style.color = "gray";
          checkbox.disabled = true;
        } else {
          if (label) label.style.color = "";
          if (desc) desc.style.color = "";
        }
      }
    }*/

/*function initSubtaskCheckboxes() {
  var checkboxes = document.querySelectorAll(".subtask-checkbox");
  checkboxes.forEach(function (checkbox) {
    var subtaskId = checkbox.getAttribute("data-id");
    if (!subtaskId) return;

    // Ambil status tersimpan dari localStorage dan set ke checkbox
    var storedStatus = localStorage.getItem("subtask_" + subtaskId);
    checkbox.checked = storedStatus === "true";
    updateCheckboxStyle(checkbox, checkbox.checked);

    checkbox.addEventListener("change", function () {
      var isChecked = checkbox.checked;
      var newStatus = isChecked ? "selesai" : "belum_selesai";

      // Gunakan route yang didefinisikan di window.routes, lalu ganti placeholder dengan id_subtask
      var updateUrl = window.routes.subtaskUpdate.replace(':id_subtask', subtaskId);

      fetch(updateUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        },
        body: JSON.stringify({ status_subtask: newStatus }),
      })
        .then(response => response.json())
        .then(function (data) {
          if (data.success) {
            // Simpan status di localStorage dan perbarui styling
            localStorage.setItem("subtask_" + subtaskId, checkbox.checked);
            updateCheckboxStyle(checkbox, checkbox.checked);
          } else {
            alert("Gagal mengupdate status subtask");
            // Jika update gagal, kembalikan kondisi checkbox ke semula
            checkbox.checked = !checkbox.checked;
            updateCheckboxStyle(checkbox, checkbox.checked);
          }
        })
        .catch(function (error) {
          alert("Error AJAX: " + error);
        });
    });
  });

  function updateCheckboxStyle(checkbox, isChecked) {
    var li = checkbox.closest("li");
    if (!li) return;
    var label = li.querySelector("label");
    var desc = li.querySelector("p.subtask-desc");
    if (isChecked) {
      if (label) label.style.color = "gray";
      if (desc) desc.style.color = "gray";
      checkbox.disabled = true;
    } else {
      if (label) label.style.color = "";
      if (desc) desc.style.color = "";
    }
  }
}*/
/****function initSubtaskCheckboxes() {
  var checkboxes = document.querySelectorAll(".subtask-checkbox");
  alert("Jumlah checkbox ditemukan: " + checkboxes.length);

  checkboxes.forEach(function (checkbox, index) {
    var subtaskId = checkbox.getAttribute("data-id");
    alert("Checkbox ke-" + index + " ID Subtask: " + subtaskId);
    if (!subtaskId) {
      alert("Subtask ID tidak ditemukan");
      return;
    }

    var storedStatus = localStorage.getItem("subtask_" + subtaskId);
    checkbox.checked = storedStatus === "true";
    updateCheckboxStyle(checkbox, checkbox.checked);

    checkbox.addEventListener("change", function () {
      var isChecked = checkbox.checked;
      var newStatus = isChecked ? "selesai" : "belum_selesai";
      var updateUrl = window.routes.subtaskStatus.replace(':id_subtask', subtaskId);

      alert("Mengirim request ke: " + updateUrl + " dengan status: " + newStatus);

      fetch(updateUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        },
        body: JSON.stringify({ status_subtask: newStatus }),
      })
        .then(response => {
          alert("Response diterima dari server, status: " + response.status);
          return response.json();
        })
        .then(function (data) {
          alert("Response JSON: " + JSON.stringify(data));
          if (data.success) {
            localStorage.setItem("subtask_" + subtaskId, checkbox.checked);
            updateCheckboxStyle(checkbox, checkbox.checked);
            alert("Status berhasil diupdate dan disimpan di localStorage");
          } else {
            alert("Gagal mengupdate status subtask dari server");
            checkbox.checked = !checkbox.checked;
            updateCheckboxStyle(checkbox, checkbox.checked);
          }
        })
        .catch(function (error) {
          alert("Terjadi error saat fetch: " + error);
        });
    });
  });

  function updateCheckboxStyle(checkbox, isChecked) {
    var li = checkbox.closest("li");
    if (!li) return;
    var label = li.querySelector("label");
    var desc = li.querySelector("p.subtask-desc");

    if (isChecked) {
      if (label) label.style.color = "gray";
      if (desc) desc.style.color = "gray";
      checkbox.disabled = true;
    } else {
      if (label) label.style.color = "";
      if (desc) desc.style.color = "";
    }
  }
}*/
function initSubtaskCheckboxes() {
  const container = document.body; // Atau ganti dengan parent spesifik seperti `.todo-card` jika ada
  alert("Delegasi event untuk checkbox subtask telah diinisialisasi");

  container.addEventListener("click", function (e) {
    const checkbox = e.target.closest(".subtask-checkbox");
    if (!checkbox) return; // Bukan klik pada checkbox, abaikan

    const subtaskId = checkbox.getAttribute("data-id");
    alert("Klik pada checkbox ID Subtask: " + subtaskId);
    if (!subtaskId) {
      alert("Subtask ID tidak ditemukan");
      return;
    }

    const isChecked = checkbox.checked;
    const newStatus = isChecked ? "selesai" : "belum_selesai";
    const updateUrl = window.routes.subtaskStatus.replace(':id_subtask', subtaskId);

    alert("Mengirim request ke: " + updateUrl + " dengan status: " + newStatus);

    fetch(updateUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
      },
      body: JSON.stringify({ status_subtask: newStatus }),
    })
      .then(response => {
        alert("Response diterima dari server, status: " + response.status);
        return response.json();
      })
      .then(function (data) {
        alert("Response JSON: " + JSON.stringify(data));
        if (data.success) {
          localStorage.setItem("subtask_" + subtaskId, isChecked);
          updateCheckboxStyle(checkbox, isChecked);
          alert("Status berhasil diupdate dan disimpan di localStorage");
        } else {
          alert("Gagal mengupdate status subtask dari server");
          checkbox.checked = !isChecked; // Revert
          updateCheckboxStyle(checkbox, !isChecked);
        }
      })
      .catch(function (error) {
        alert("Terjadi error saat fetch: " + error);
      });
  });

  // Jalankan update style saat halaman dimuat
  document.querySelectorAll(".subtask-checkbox").forEach(function (checkbox) {
    const subtaskId = checkbox.getAttribute("data-id");
    const storedStatus = localStorage.getItem("subtask_" + subtaskId);
    checkbox.checked = storedStatus === "true";
    updateCheckboxStyle(checkbox, checkbox.checked);
  });

  function updateCheckboxStyle(checkbox, isChecked) {
    const li = checkbox.closest("li");
    if (!li) return;
    const label = li.querySelector("label");
    const desc = li.querySelector("p.subtask-desc");

    if (isChecked) {
      if (label) label.style.color = "gray";
      if (desc) desc.style.color = "gray";
      checkbox.disabled = true;
    } else {
      if (label) label.style.color = "";
      if (desc) desc.style.color = "";
    }
  }
}










document.addEventListener("DOMContentLoaded", function(){
  initSubtaskCheckboxes();
});

   /**
     * Modul: Update Status Checkbox Subtask
     */
    /*function initSubtaskCheckboxes() {
      var checkboxes = document.querySelectorAll(".subtask-checkbox");
      checkboxes.forEach(function(checkbox) {
        var subtaskId = checkbox.getAttribute("data-id");
        if (!subtaskId) return;
        // Ambil status tersimpan dari localStorage
        var storedStatus = localStorage.getItem("subtask_" + subtaskId);
        checkbox.checked = storedStatus === "true";
        updateCheckboxStyle(checkbox, checkbox.checked);
        checkbox.addEventListener("change", function() {
          var isChecked = checkbox.checked;
          var newStatus = isChecked ? "selesai" : "belum_selesai";
          fetch(`/subtask/update/${subtaskId}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({ status_subtask: newStatus })
          })
            .then(response => response.text())
            .then(function(text) {
              try {
                var data = JSON.parse(text);
                if (data.success) {
                  localStorage.setItem("subtask_" + subtaskId, checkbox.checked);
                  updateCheckboxStyle(checkbox, checkbox.checked);
                } else {
                  alert("Gagal mengupdate status subtask");
                  checkbox.checked = !checkbox.checked;
                  updateCheckboxStyle(checkbox, checkbox.checked);
                }
              } catch (e) {
                alert("Error parsing JSON: " + e);
              }
            })
            .catch(function(error) {
              alert("Error AJAX: " + error);
            });
        });
      });

      function updateCheckboxStyle(checkbox, isChecked) {
        var li = checkbox.closest("li");
        if (!li) return;
        var label = li.querySelector("label");
        var desc = li.querySelector("p.subtask-desc");
        if (isChecked) {
          if (label) label.style.color = "gray";
          if (desc) desc.style.color = "gray";
          checkbox.disabled = true;
        } else {
          if (label) label.style.color = "";
          if (desc) desc.style.color = "";
        }
      }
    }*/