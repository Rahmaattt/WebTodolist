// export function initTaskStatusUpdater() {
//   document.querySelectorAll(".update-status-form").forEach(function (form) {
//     var button = form.querySelector(".done-btn");
//     var hiddenInput = form.querySelector("input[name='status_task']");
//     var card = form.closest(".todo-card");
//     if (!card) return;
//     var cardId = card.getAttribute("data-task-id");
//     if (!cardId || !button || !hiddenInput) return;

//     // Terapkan status tersimpan dari localStorage
//     var storedStatus = localStorage.getItem("card_status_" + cardId);
//     if (storedStatus) {
//       applyStatusToButton(button, storedStatus);
//       hiddenInput.value = storedStatus;
//     }

//     button.addEventListener("click", function (e) {
//       e.preventDefault();
//       var deadlineStr = card.getAttribute("data-deadline");
//       if (deadlineStr.indexOf(" ") > -1) {
//         deadlineStr = deadlineStr.replace(" ", "T");
//       }
//       var deadline = new Date(deadlineStr);
//       var now = new Date();
//       // Tentukan status baru
//       var newStatus = now > deadline ? "terlambat" : hiddenInput.value === "selesai" ? "belum_selesai" : "selesai";
//       hiddenInput.value = newStatus;

//       var csrfToken = document.querySelector('meta[name="csrf-token"]').content;
//       var formData = new FormData();
//       formData.append("_token", csrfToken);
//       formData.append("status_task", newStatus);

//       fetch(form.dataset.action, {
//         method: "POST",
//         body: formData
//       })
//         .then((response) => response.json())
//         .then(function (data) {
//           if (data.success) {
//             applyStatusToButton(button, data.new_status);
//             localStorage.setItem("card_status_" + cardId, data.new_status);
//           }
//         })
//         .catch((error) => console.error("Error:", error));
//     });
//   });

//   // Helper: Update tampilan tombol berdasarkan status
//   function applyStatusToButton(button, status) {
//     // Ambil card terkait dengan tombol tersebut
//     var card = button.closest(".todo-card");
//     if (!card) return;
//     // Ambil header dari card tersebut
//     var head = card.querySelector(".card-header");
//     if (status === "terlambat") {
//       button.textContent = "Terlambat";
//       button.classList.remove("btn-success", "btn-warning");
//       button.classList.add("btn-danger");
//       button.disabled = true;
//       head.classList.remove("bg-primary");
//       head.classList.add("bg-danger");
//     } else if (status === "selesai") {
//       button.textContent = "Selesai";
//       button.classList.remove("btn-primary", "btn-danger");
//       button.classList.add("btn-success");
//       button.disabled = true;
//       head.classList.remove("bg-danger", "bg-primary");
//       head.classList.add("bg-success");
//     } else if (status === "belum_selesai") {
//       button.textContent = "Selesai";
//       button.classList.remove("btn-success", "btn-danger");
//       button.classList.add("btn-primary");
//       head.classList.remove("bg-warning", "bg-danger");
//       head.classList.add("bg-primary");
//     }
//   }
// }

/*function initTaskStatusUpdater() {
  document.querySelectorAll(".update-status-form").forEach(function (form) {
    var button = form.querySelector(".done-btn");
    var hiddenInput = form.querySelector("input[name='status_task']");
    var card = form.closest(".todo-card");
    if (!card) return;
    var cardId = card.getAttribute("data-task-id");
    if (!cardId || !button || !hiddenInput) return;

    // Terapkan status tersimpan dari localStorage
    var storedStatus = localStorage.getItem("card_status_" + cardId);
    if (storedStatus) {
      applyStatusToButton(button, storedStatus);
      hiddenInput.value = storedStatus;
    }

    button.addEventListener("click", function (e) {
      e.preventDefault();
      var deadlineStr = card.getAttribute("data-deadline");
      if (deadlineStr.indexOf(" ") > -1) {
        deadlineStr = deadlineStr.replace(" ", "T");
      }
      var deadline = new Date(deadlineStr);
      var now = new Date();
      // Tentukan status baru
      var newStatus = now > deadline ? "terlambat" : hiddenInput.value === "selesai" ? "belum_selesai" : "selesai";
      hiddenInput.value = newStatus;

      var csrfToken = document.querySelector('meta[name="csrf-token"]').content;
      var formData = new FormData();
      formData.append("_token", csrfToken);
      formData.append("status_task", newStatus);

      // Ganti URL endpoint dengan route Laravel
      fetch(`/dashboard/updateStatus/${cardId}`, {
        method: "POST",
        body: formData
      })
        .then((response) => response.json())
        .then(function (data) {
          if (data.success) {
            applyStatusToButton(button, data.new_status);
            localStorage.setItem("card_status_" + cardId, data.new_status);
          }
        })
        .catch((error) => console.error("Error:", error));
    });
  });

  // Helper: Update tampilan tombol berdasarkan status
  function applyStatusToButton(button, status) {
    // Ambil card terkait dengan tombol tersebut
    var card = button.closest(".todo-card");
    if (!card) return;
    // Ambil header dari card tersebut
    var head = card.querySelector(".card-header");
    if (status === "terlambat") {
      button.textContent = "Terlambat";
      button.classList.remove("btn-success", "btn-warning");
      button.classList.add("btn-danger");
      button.disabled = true;
      head.classList.remove("bg-primary");
      head.classList.add("bg-danger");
    } else if (status === "selesai") {
      button.textContent = "Selesai";
      button.classList.remove("btn-primary", "btn-danger");
      button.classList.add("btn-success");
      button.disabled = true;
      head.classList.remove("bg-danger", "bg-primary");
      head.classList.add("bg-success");
    } else if (status === "belum_selesai") {
      button.textContent = "Selesai";
      button.classList.remove("btn-success", "btn-danger");
      button.classList.add("btn-primary");
      head.classList.remove("bg-warning", "bg-danger");
      head.classList.add("bg-primary");
    }
  }
}*/
/*function initTaskStatusUpdater() {
  document.addEventListener("click", function (e) {
    const button = e.target.closest(".done-btn");
    if (!button) return;

    const form = button.closest(".update-status-form");
    const hiddenInput = form?.querySelector("input[name='status_task']");
    const card = form?.closest(".todo-card");

    if (!form || !hiddenInput || !card) return;

    const cardId = card.getAttribute("data-task-id");
    if (!cardId) return;

    // Ambil deadline dari atribut data
    let deadlineStr = card.getAttribute("data-deadline") || "";
    if (deadlineStr.includes(" ")) {
      deadlineStr = deadlineStr.replace(" ", "T");
    }

    const deadline = new Date(deadlineStr);
    const now = new Date();

    // Tentukan status baru
    let newStatus;
    if (now > deadline) {
      newStatus = "terlambat";
    } else {
      newStatus = hiddenInput.value === "selesai" ? "belum_selesai" : "selesai";
    }

    // Update value input tersembunyi
    hiddenInput.value = newStatus;

    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

    // Siapkan FormData
    const formData = new FormData();
    formData.append("_token", csrfToken);
    formData.append("status_task", newStatus);

    // Kirim ke backend
    fetch(`/dashboard/updateStatus/${cardId}`, {
      method: "POST",
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          applyStatusToButton(button, data.new_status);
          localStorage.setItem("card_status_" + cardId, data.new_status);
        } else {
          Swal.fire("Gagal mengubah status!", data.message || "", "warning");
        }
      })
      .catch(err => {
        console.error("Error:", err);
        Swal.fire("Terjadi kesalahan!", err.message, "error");
      });
  });

  // Terapkan status tersimpan dari localStorage saat load
  document.querySelectorAll(".todo-card").forEach(card => {
    const cardId = card.getAttribute("data-task-id");
    const storedStatus = localStorage.getItem("card_status_" + cardId);
    if (!storedStatus) return;

    const button = card.querySelector(".done-btn");
    const hiddenInput = card.querySelector("input[name='status_task']");
    if (button && hiddenInput) {
      applyStatusToButton(button, storedStatus);
      hiddenInput.value = storedStatus;
    }
  });

  // Helper: Terapkan tampilan berdasarkan status
  function applyStatusToButton(button, status) {
    const card = button.closest(".todo-card");
    const head = card?.querySelector(".card-header");

    if (!card || !head) return;

    // Reset class
    button.classList.remove("btn-success", "btn-danger", "btn-primary");
    head.classList.remove("bg-success", "bg-danger", "bg-primary");

    switch (status) {
      case "terlambat":
        button.textContent = "Terlambat";
        button.classList.add("btn-danger");
        button.disabled = true;
        head.classList.add("bg-danger");
        break;
      case "selesai":
        button.textContent = "Selesai";
        button.classList.add("btn-success");
        button.disabled = true;
        head.classList.add("bg-success");
        break;
      default:
        button.textContent = "Selesai";
        button.classList.add("btn-primary");
        button.disabled = false;
        head.classList.add("bg-primary");
        break;
    }
  }
}*/
/*******function initTaskStatusUpdater() {
  /*document.addEventListener("click", function(e) {
    const btn = e.target.closest(".done-btn");
    if (!btn) return;

    e.preventDefault();
    const taskId = btn.dataset.id;
    const form = btn.closest(".update-status-form");
    const hiddenInput = form.querySelector("input[name='status_task']");

    // toggle nilai
    const newStatus = hiddenInput.value === "selesai" ? "belum_selesai" : "selesai";
    hiddenInput.value = newStatus;

    fetch(`/dashboard/updateStatus/${taskId}`, {
      method: "POST",
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      },
      body: new URLSearchParams({ status_task: newStatus })
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        // update tampilan tombol
        btn.textContent = newStatus === "selesai" ? "Batalkan" : "Selesai";
        btn.classList.toggle("btn-primary");
        btn.classList.toggle("btn-warning");
      }
    })
    .catch(err => console.error(err));
  });*
  document.getElementById("todo-list").addEventListener("click", function(e) {
  const target = e.target;
  
  // Cek apakah yang diklik adalah tombol dalam update-status-form
  if (target.closest(".done-btn")) {
    e.preventDefault();
    const form = target.closest(".update-status-form");
    if (!form) return;
    
    // Proses update status sama seperti sebelumnya
    const card = form.closest(".todo-card");
    if (!card) return;
    const cardId = card.getAttribute("data-task-id");
    
    // Ambil input tersembunyi
    const hiddenInput = form.querySelector("input[name='status_task']");
    // Update nilainya
    let newStatus = hiddenInput.value; // atau kalkulasi baru status
    
    // Contoh: toggle status
    newStatus = newStatus === 'selesai' ? 'belum_selesai' : 'selesai';
    hiddenInput.value = newStatus;
    
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
    const formData = new FormData();
    formData.append("_token", csrfToken);
    formData.append("status_task", newStatus);
    
    fetch(`/dashboard/updateStatus/${cardId}`, {
      method: "POST",
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          // Perbarui tampilan tombol
          if (data.new_status === 'selesai') {
            target.textContent = "Selesai";
            target.classList.remove("btn-primary");
            target.classList.add("btn-success");
          } else {
            target.textContent = "Selesai";
            target.classList.remove("btn-success");
            target.classList.add("btn-primary");
          }
          // Jika perlu, simpan status ke localStorage
          localStorage.setItem("card_status_" + cardId, data.new_status);
        }
      })
      .catch(error => {
        console.error(error);
        alert("Error updating status: " + error.message);
      });
  }
});
}*/

function initTaskStatusUpdater() {
  document.getElementById("todo-list").addEventListener("click", function (e) {
    const target = e.target;

    // Cek apakah tombol selesai ditekan
    if (target.closest(".done-btn")) {
      e.preventDefault();
      const form = target.closest(".update-status-form");
      if (!form) return;

      const card = form.closest(".todo-card");
      if (!card) return;

      const cardId = card.getAttribute("data-task-id");
      const hiddenInput = form.querySelector("input[name='status_task']");
      let newStatus = hiddenInput.value;

      // Cek apakah lewat deadline
      const deadlineStr = card.getAttribute("data-deadline");
      const deadline = deadlineStr ? new Date(deadlineStr.replace(" ", "T")) : null;
      const now = new Date();

      if (deadline && now > deadline && newStatus !== "selesai") {
        newStatus = "terlambat";
      } else {
        // Toggle status selesai / belum
        newStatus = newStatus === "selesai" ? "belum_selesai" : "selesai";
      }

      hiddenInput.value = newStatus;

      const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
      const formData = new FormData();
      formData.append("_token", csrfToken);
      formData.append("status_task", newStatus);

      fetch(`/dashboard/updateStatus/${cardId}`, {
        method: "POST",
        body: formData
      })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            applyStatusToButton(target, data.new_status);
            localStorage.setItem("card_status_" + cardId, data.new_status);
          }
        })
        .catch(error => {
          console.error(error);
          alert("Error updating status: " + error.message);
        });
    }
  });
}

// Fungsi pembantu untuk update tampilan tombol dan header
function applyStatusToButton(button, status) {
  const card = button.closest(".todo-card");
  if (!card) return;

  const head = card.querySelector(".card-header");

  // Reset class terlebih dahulu
  button.classList.remove("btn-primary", "btn-success", "btn-danger", "btn-warning");
  head.classList.remove("bg-primary", "bg-success", "bg-danger", "bg-warning");

  if (status === "terlambat") {
    button.textContent = "Terlambat";
    button.classList.add("btn-danger");
    button.disabled = true;

    head.classList.add("bg-danger");
  } else if (status === "selesai") {
    button.textContent = "Selesai";
    button.classList.add("btn-success");
    button.disabled = true;

    head.classList.add("bg-success");
  } else if (status === "belum_selesai") {
    button.textContent = "Selesai";
    button.classList.add("btn-primary");
    button.disabled = false;

    head.classList.add("bg-primary");
  }
}




/*function initTaskStatusUpdater() {
  document.addEventListener("click", function(e) {
    const btn = e.target.closest(".done-btn");
    if (!btn) return;

    alert("Tombol selesai/batalkan diklik");

    e.preventDefault();
    const taskId = btn.dataset.id;
    const form = btn.closest(".update-status-form");
    const hiddenInput = form.querySelector("input[name='status_task']");

    if (!form || !hiddenInput || !taskId) {
      alert("Form, hidden input, atau taskId tidak ditemukan!");
      return;
    }

    // toggle nilai
    const newStatus = hiddenInput.value === "selesai" ? "belum_selesai" : "selesai";
    hiddenInput.value = newStatus;

    alert(`Mengirim status baru: ${newStatus} untuk task ID: ${taskId}`);

    fetch(`/dashboard/updateStatus/${taskId}`, {
      method: "POST",
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      },
      body: new URLSearchParams({ status_task: newStatus })
    })
    .then(r => r.json())
    .then(data => {
      swal.fire("Respons diterima dari server: " + JSON.stringify(data));
      if (data.success) {
        // update tampilan tombol
        btn.textContent = newStatus === "selesai" ? "Batalkan" : "Selesai";
        btn.classList.toggle("btn-primary");
        btn.classList.toggle("btn-warning");
        alert("Status task berhasil diperbarui");
      } else {
        alert("Gagal memperbarui status task");
      }
    })
    .catch(err => {
      swal.fire("Terjadi error saat mengirim request: " + err);
      console.error(err);
    });
  });
}*/



document.addEventListener("DOMContentLoaded", function(){
  initTaskStatusUpdater();
});