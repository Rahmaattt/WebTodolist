/*function initTaskUpdateForm() {
  const formUpdateTask = document.getElementById("formUpdateTask");
  if (!formUpdateTask) return;

  formUpdateTask.addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(formUpdateTask);
    const taskId = document.getElementById("updateTaskId").value;

    // Gantilah placeholder ":id" dengan taskId di URL
    const updateUrl = window.routes.updateTask.replace(":id_task", taskId);

    fetch(updateUrl, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json"
      }
    })
      .then(response => response.json())
      .then(function (data) {
        if (data.success) {
          Swal.fire(data.message, "", "success");

          // Perbarui data pada tombol edit agar tidak perlu refresh
          const button = document.querySelector(`.edit-btn[data-task-id='${taskId}']`);
          if (button) {
            button.dataset.task = data.task.judul_task;
            button.dataset.keterangan = data.task.keterangan_task;
            button.dataset.deadline = data.task.deadline;
          }

          // Tutup modal
          const modalEl = document.getElementById("modalUpdateTask");
          const modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire(data.message, "", "warning");
        }
      })
      .catch(function (error) {
        Swal.fire("Terjadi kesalahan!", error, "error");
      });
  });
}*/
/*function initTaskUpdateForm() {
  document.addEventListener("submit", function (e) {
    const formUpdateTask = e.target.closest("#formUpdateTask");
    if (!formUpdateTask) return;

    e.preventDefault();

    const formData = new FormData(formUpdateTask);
    const taskId = document.getElementById("updateTaskId").value;
    const updateUrl = window.routes.updateTask.replace(":id_task", taskId);

    fetch(updateUrl, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json",
      },
    })
      .then((response) => response.json())
      .then(function (data) {
        if (data.success) {
          Swal.fire(data.message, "", "success");

          // Update data tombol edit yang bersangkutan
          const button = document.querySelector(`.edit-btn[data-task-id='${taskId}']`);
          if (button) {
            button.dataset.task = data.task.judul_task;
            button.dataset.keterangan = data.task.keterangan_task;
            button.dataset.deadline = data.task.deadline;
          }

          // Tutup modal
          const modalEl = document.getElementById("modalUpdateTask");
          const modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire(data.message, "", "warning");
        }
      })
      .catch(function (error) {
        alert("Terjadi kesalahan pada fetch: " + error.message);
        alert("Detail error:", error);
});

  });
}*/
/*function initTaskUpdateForm() {
  document.addEventListener("submit", function (e) {
    const formUpdateTask = e.target.closest("#formUpdateTask");
    if (!formUpdateTask) return;

    e.preventDefault();

    const formData = new FormData(formUpdateTask);
    const taskId = document.getElementById("updateTaskId").value;
    const updateUrl = window.routes.updateTask.replace(":id_task", taskId);

    fetch(updateUrl, {
      method: "PUT",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json",
      },
    })
      .then((response) => {
        if (!response.ok) {
          // Jika response bukan 2xx
          throw new Error(`HTTP error ${response.status}`);
        }
        return response.json();
      })
      .then(function (data) {
        alert("Data diterima: " + JSON.stringify(data)); // debug log

        if (data.success) {
          Swal.fire(data.message || "Berhasil!", "", "success");

          // Pastikan data.task tersedia
          if (data.task) {
            const button = document.querySelector(`.edit-btn[data-task-id='${taskId}']`);
            if (button) {
              button.dataset.task = data.task.judul_task || "";
              button.dataset.keterangan = data.task.keterangan_task || "";
              button.dataset.deadline = data.task.deadline || "";
            }
          }

          // Tutup modal
          const modalEl = document.getElementById("modalUpdateTask");
          const modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire(data.message || "Gagal memperbarui task", "", "warning");
        }
      })
      .catch(function (error) {
        alert("Terjadi kesalahan pada fetch: " + error.message);
        console.error("Detail error:", error);
      });
  });
}*/
/*function initTaskUpdateForm() {
  document.addEventListener("submit", function (e) {
    const formUpdateTask = e.target.closest("#formUpdateTask");
    if (!formUpdateTask) return;

    e.preventDefault();

    const formData = new FormData(formUpdateTask);
    const taskId = document.getElementById("updateTaskId").value;
    const updateUrl = `/dashboard/update/${taskId}`; // langsung hardcode url

    fetch(updateUrl, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json",
      },
    })
      .then((response) => {
        if (!response.ok) throw new Error(`HTTP error ${response.status}`);
        return response.json();
      })
      .then((data) => {
        if (data.success) {
          Swal.fire(data.message || "Berhasil memperbarui task", "", "success");

          // Update dataset tombol edit (jika ada)
          const button = document.querySelector(`.edit-btn[data-task-id='${taskId}']`);
          if (button && data.task) {
            button.dataset.task = data.task.judul_task;
            button.dataset.keterangan = data.task.keterangan_task;
            button.dataset.deadline = data.task.deadline;
          }

          // Tutup modal
          const modalEl = document.getElementById("modalUpdateTask");
          const modalInstance = bootstrap.Modal.getInstance(modalEl);
          if (modalInstance) modalInstance.hide();
        } else {
          Swal.fire(data.message || "Gagal memperbarui task", "", "warning");
        }
      })
      .catch((error) => {
        alert("Fetch error: " + error.message);
        console.error("Detail error:", error);
      });
  });
}*/
function initTaskUpdateForm() {
  document.addEventListener("submit", function (e) {
    const formUpdateTask = e.target.closest("#formUpdateTask");
    if (!formUpdateTask) return;

    e.preventDefault();

    const formData = new FormData(formUpdateTask);
    const taskId = document.getElementById("updateTaskId").value;
    const updateUrl = `/dashboard/update/${taskId}`;

    fetch(updateUrl, {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
        "Accept": "application/json",
      },
    })
      .then((response) => {
        if (!response.ok) throw new Error(`HTTP error ${response.status}`);
        return response.json();
      })
      .then((data) => {
        if (!data.success) {
          return Swal.fire(data.message || "Gagal memperbarui task", "", "warning");
        }

        // 1) Tampilkan toast sukses
        Swal.fire(data.message || "Task berhasil diperbarui", "", "success");

        // 2) Ambil elemen kartu task di halaman
        const card = document.querySelector(`.todo-card[data-task-id='${taskId}']`);
        if (card && data.task) {
          // a) Update teks judul
          const titleEl = card.querySelector(".task-title .task-text");
          if (titleEl) titleEl.textContent = data.task.judul_task;

          // b) Update keterangan di dua tempat: di tombol edit dataset & di dalam card-body
          // — tombol edit
          const editBtn = card.querySelector(`.edit-btn[data-task-id='${taskId}']`);
          if (editBtn) {
            editBtn.dataset.task = data.task.judul_task;
            editBtn.dataset.keterangan = data.task.keterangan_task;
            editBtn.dataset.deadline = data.task.deadline;
          }
          // — di card-body (jika ada elemen .task-description)
          const descEl = card.querySelector(".task-description");
          if (descEl) descEl.textContent = `Keterangan: ${data.task.keterangan_task}`;

          // c) Update deadline
          const deadlineEl = card.querySelector(".task-deadline");
          if (deadlineEl) deadlineEl.textContent = `Deadline: ${data.task.deadline}`;

          // d) Update status badge/text & tombol done
          const statusSpan = card.querySelector(".due-date .status-task");
          if (statusSpan) statusSpan.textContent = `Status Task: ${data.task.status_task}`;

          const doneBtn = card.querySelector(`.done-btn[data-id='${taskId}']`);
          if (doneBtn) {
            doneBtn.dataset.status = data.task.status_task;
            if (data.task.status_task === "selesai") {
              doneBtn.classList.remove("btn-primary");
              doneBtn.classList.add("btn-warning");
              doneBtn.textContent = "Batalkan";
            } else {
              doneBtn.classList.remove("btn-warning");
              doneBtn.classList.add("btn-primary");
              doneBtn.textContent = "Selesai";
            }
          }
        }

        // 3) Tutup modal
        const modalEl = document.getElementById("modalUpdateTask");
        const modalInstance = bootstrap.Modal.getInstance(modalEl);
        if (modalInstance) modalInstance.hide();
      })
      .catch((error) => {
        console.error("Detail error:", error);
        Swal.fire("Error!", "Terjadi kesalahan: " + error.message, "error");
      });
  });
}






document.addEventListener("DOMContentLoaded", function(){
  initTaskUpdateForm();
});