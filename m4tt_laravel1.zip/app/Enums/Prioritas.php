<?php

namespace App\Enums;

enum Prioritas: string
{
    case RENDAH = 'rendah';
    case SEDANG = 'sedang';
    case TINGGI = 'tinggi';
}
