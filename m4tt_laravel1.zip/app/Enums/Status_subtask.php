<?php

namespace App\Enums;

enum Status_subtask: string
{
    case SELESAI = 'selesai';
    case BELUM_SELESAI = 'belum_selesai';
}
