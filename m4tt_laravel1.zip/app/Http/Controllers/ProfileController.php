<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    // Menampilkan halaman profil
    public function index()
    {
        $user = Auth::user();
        return view('profile', compact('user'));
    }

    // Memproses update data profil (contoh: update foto profil dan nama)
    public function update(Request $request)
    {
        $request->validate([
            'profile_photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'name' => 'nullable|string|max:255',
        ]);

        $user = Auth::user();

        if ($request->hasFile('profile_photo')) {
            // Simpan file di storage (folder: storage/app/public/profile_photos)
            $path = $request->file('profile_photo')->store('profile_photos', 'public');

            // Salin file ke folder public (misalnya, public/uploads) jika diperlukan
            $storagePath = storage_path('app/public/' . $path);
            $publicPath = public_path('uploads/' . $path);
            if (!file_exists(dirname($publicPath))) {
                mkdir(dirname($publicPath), 0777, true);
            }
            copy($storagePath, $publicPath);

            // Simpan path ke database (misalnya, hanya menyimpan path relatif)
            $user->profile_photo = $path;
        }

        if ($request->filled('name')) {
            $user->name = $request->input('name');
        }

        $user->save();

        return redirect()->back()->with('success', 'Profil berhasil diperbarui.');
    }
    
    public function profile(Request $request) {
      $request->validate([
        'profile_photo' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
      ]);

      if ($request->hasFile('profile_photo')) {
        // Simpan file ke storage dengan disk 'public'
        $path = $request->file('profile_photo')->store('profile_photos', 'public');

        // Tentukan path file di storage
        $storagePath = storage_path('app/public/' . $path);
        
        // Tentukan path tujuan di public (misalnya, simpan di public/uploads)
        $publicPath = public_path('uploads/' . $path);
        
        // Pastikan direktori tujuan ada, jika tidak buat direktori tersebut
        if (!file_exists(dirname($publicPath))) {
            mkdir(dirname($publicPath), 0777, true);
        }
        
        // Salin file dari storage ke folder public
        if (!copy($storagePath, $publicPath)) {
            return back()->with('error', 'Gagal menyalin file ke folder public.');
        }

        // Ambil user yang sedang login
        $user = Auth::user();

        // Simpan path file (misal path relatif dari folder storage) ke kolom profile_photo di database
        $user->profile_photo = $path;
        $user->save();

        return back()->with('success', 'Profil berhasil diperbarui.');
      }

      return back()->with('error', 'Tidak ada file yang diupload.');
    }
}