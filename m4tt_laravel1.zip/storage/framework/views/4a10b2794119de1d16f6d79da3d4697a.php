<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($resetData['subject']); ?></title>
</head>
<body>
    <h1>Halo, <?php echo e($resetData['name']); ?>!</h1>
    <p>Token: <?php echo e($resetData['token']); ?></p>
    <p>Link: <?php echo e($resetData['resetLink']); ?></p>
</body>
</html><?php /**PATH /storage/emulated/0/Download/m4tt_laravel1/resources/views/mail/resetPassword.blade.php ENDPATH**/ ?>