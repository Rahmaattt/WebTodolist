<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($data['subject']); ?></title>
</head>
<body>
    <h1>Halo, <?php echo e($data['name']); ?>!</h1>
    <p><?php echo e($data['message']); ?></p>
    <hr>
    <p><strong>ID Task:</strong> <?php echo e($data['id_task']); ?></p>
    <p><strong>Keterangan:</strong> <?php echo e($data['keterangan_task']); ?></p>
    <p><strong>Deadline:</strong> <?php echo e($data['deadline']); ?></p>
</body>
</html><?php /**PATH /storage/emulated/0/Download/m4tt_laravel1/resources/views/mail/notifikasi.blade.php ENDPATH**/ ?>