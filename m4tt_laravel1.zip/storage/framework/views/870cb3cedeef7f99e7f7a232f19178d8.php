<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Profile</title>
  <!-- Menggunakan Bootstrap 5 dari CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .profile-img {
      width: 150px;
      height: 150px;
      object-fit: cover;
    }
  </style>
</head>
<body>
  <div class="container mt-5">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="row g-4">
          <!-- Kolom foto profil dan informasi dasar -->
          <div class="col-md-4 text-center border-end">
            <?php if($user->profile_photo): ?>
              <img src="<?php echo e(asset('uploads/' . $user->profile_photo)); ?>" alt="Foto Profil" class="rounded-circle profile-img mb-3">
            <?php else: ?>
              <img src="<?php echo e(asset('images/default-profile.png')); ?>" alt="Foto Profil" class="rounded-circle profile-img mb-3">
            <?php endif; ?>
            <h5><?php echo e($user->name); ?></h5>
            <p class="text-muted"><?php echo e($user->email); ?></p>
          </div>
          <!-- Kolom form update profile -->
          <div class="col-md-8">
            <h4>Update Profil</h4>
            <!-- Notifikasi jika ada pesan sukses -->
            <?php if(session('success')): ?>
              <div class="alert alert-success">
                <?php echo e(session('success')); ?>

              </div>
            <?php endif; ?>
            <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <!-- Field ganti foto profil -->
              <div class="mb-3">
                <label for="profile_photo" class="form-label">Ganti Foto Profil</label>
                <input type="file" class="form-control" name="profile_photo" id="profile_photo">
                <?php if($errors->has('profile_photo')): ?>
                  <small class="text-danger"><?php echo e($errors->first('profile_photo')); ?></small>
                <?php endif; ?>
              </div>
              <!-- Field update nama -->
              <div class="mb-3">
                <label for="name" class="form-label">Nama</label>
                <input type="text" class="form-control" name="name" id="name" value="<?php echo e($user->name); ?>">
              </div>
              <!-- Tambahkan field lain sesuai kebutuhan -->
              <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>
          </div>
        </div> <!-- end row -->
      </div> <!-- end card-body -->
    </div> <!-- end card -->
  </div> <!-- end container -->

  <!-- Script Bootstrap Bundle -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH /storage/emulated/0/Download/m4tt_laravel1/resources/views/profile.blade.php ENDPATH**/ ?>